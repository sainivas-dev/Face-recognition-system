#!/bin/bash

echo "Stopping Face Recognition Backend..."

if [ -f ".backend.pid" ]; then
    kill $(cat .backend.pid) 2>/dev/null
    rm .backend.pid
    echo "✅ Backend stopped"
fi

if [ -f ".ai-service.pid" ]; then
    kill $(cat .ai-service.pid) 2>/dev/null
    rm .ai-service.pid
    echo "✅ AI Service stopped"
fi

echo "All services stopped"
