from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional
import logging
from datetime import datetime

from face_service import FaceRecognitionService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Face Recognition AI Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

face_service = FaceRecognitionService()

class ImageRequest(BaseModel):
    image: str = Field(..., description="Base64 encoded image")

class CompareRequest(BaseModel):
    embedding1: List[float]
    embedding2: List[float]

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "model": face_service.model_name
    }

@app.post("/api/extract-embedding")
async def extract_embedding(request: ImageRequest):
    try:
        result = face_service.extract_embedding(request.image)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/compare-embeddings")
async def compare_embeddings(request: CompareRequest):
    try:
        result = face_service.compare_embeddings(request.embedding1, request.embedding2)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/detect-face")
async def detect_face(request: ImageRequest):
    try:
        result = face_service.detect_face(request.image)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
