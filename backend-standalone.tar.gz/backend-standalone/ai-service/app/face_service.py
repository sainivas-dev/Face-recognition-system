import base64
import cv2
import numpy as np
from deepface import DeepFace
import logging
from typing import List, Dict
import os

logger = logging.getLogger(__name__)

class FaceRecognitionService:
    def __init__(self):
        """Initialize face recognition service with DeepFace"""
        self.model_name = os.getenv('FACE_MODEL', 'Facenet512')  # Facenet512, VGG-Face, ArcFace
        self.detector_backend = os.getenv('DETECTOR_BACKEND', 'opencv')  # opencv, retinaface, mtcnn
        self.distance_metric = 'cosine'  # cosine, euclidean, euclidean_l2
        self.threshold = float(os.getenv('FACE_MATCH_THRESHOLD', '0.4'))
        
        logger.info(f"Initialized Face Recognition Service")
        logger.info(f"Model: {self.model_name}, Detector: {self.detector_backend}")
        
        # Warm up the model
        self._warmup_model()
    
    def _warmup_model(self):
        """Warm up the model by making a dummy prediction"""
        try:
            # Create a dummy image
            dummy_img = np.zeros((224, 224, 3), dtype=np.uint8)
            DeepFace.represent(
                img_path=dummy_img,
                model_name=self.model_name,
                detector_backend=self.detector_backend,
                enforce_detection=False
            )
            logger.info("Model warmed up successfully")
        except Exception as e:
            logger.warning(f"Model warmup failed: {str(e)}")
    
    def _decode_base64_image(self, base64_string: str) -> np.ndarray:
        """Decode base64 string to numpy array (image)"""
        try:
            # Remove data URL prefix if present
            if ',' in base64_string:
                base64_string = base64_string.split(',')[1]
            
            # Decode base64 to bytes
            img_bytes = base64.b64decode(base64_string)
            
            # Convert bytes to numpy array
            nparr = np.frombuffer(img_bytes, np.uint8)
            
            # Decode image
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if img is None:
                raise ValueError("Failed to decode image")
            
            return img
        except Exception as e:
            logger.error(f"Error decoding base64 image: {str(e)}")
            raise ValueError(f"Invalid image data: {str(e)}")
    
    def extract_embedding(self, image_base64: str) -> Dict:
        """
        Extract face embedding from base64 encoded image
        
        Args:
            image_base64: Base64 encoded image string
            
        Returns:
            Dictionary with success status, embedding, and confidence
        """
        try:
            # Decode image
            img = self._decode_base64_image(image_base64)
            
            # Extract face embedding using DeepFace
            embeddings = DeepFace.represent(
                img_path=img,
                model_name=self.model_name,
                detector_backend=self.detector_backend,
                enforce_detection=True  # Raise error if no face detected
            )
            
            if not embeddings or len(embeddings) == 0:
                return {
                    "success": False,
                    "message": "No face detected in image"
                }
            
            # Get the first face embedding
            embedding_dict = embeddings[0]
            embedding = embedding_dict.get('embedding', [])
            
            # Calculate confidence (normalized)
            # DeepFace doesn't provide confidence directly, so we use 1.0 for successful detection
            confidence = 1.0
            
            # Check if face region exists and use its dimensions as a proxy for quality
            if 'facial_area' in embedding_dict:
                facial_area = embedding_dict['facial_area']
                area = (facial_area['w'] * facial_area['h'])
                # Normalize confidence based on face size (larger face = higher confidence)
                confidence = min(1.0, area / (img.shape[0] * img.shape[1]) * 5)
            
            logger.info(f"Extracted embedding of size {len(embedding)}, confidence: {confidence:.3f}")
            
            return {
                "success": True,
                "embedding": embedding,
                "confidence": confidence
            }
            
        except ValueError as e:
            logger.error(f"Face not detected: {str(e)}")
            return {
                "success": False,
                "message": "No face detected in image. Please ensure good lighting and face visibility."
            }
        except Exception as e:
            logger.error(f"Error extracting embedding: {str(e)}")
            return {
                "success": False,
                "message": f"Error processing image: {str(e)}"
            }
    
    def compare_embeddings(self, embedding1: List[float], embedding2: List[float]) -> Dict:
        """
        Compare two face embeddings
        
        Args:
            embedding1: First face embedding vector
            embedding2: Second face embedding vector
            
        Returns:
            Dictionary with similarity score and match status
        """
        try:
            # Convert to numpy arrays
            emb1 = np.array(embedding1)
            emb2 = np.array(embedding2)
            
            # Calculate cosine similarity
            if self.distance_metric == 'cosine':
                distance = self._cosine_distance(emb1, emb2)
            elif self.distance_metric == 'euclidean':
                distance = np.linalg.norm(emb1 - emb2)
            elif self.distance_metric == 'euclidean_l2':
                distance = np.linalg.norm(emb1 - emb2) / np.sqrt(len(emb1))
            else:
                distance = self._cosine_distance(emb1, emb2)
            
            # Convert distance to similarity (0-1 scale, where 1 is most similar)
            if self.distance_metric == 'cosine':
                similarity = 1 - distance  # Cosine distance is already 0-1
            else:
                # For Euclidean, normalize using typical threshold
                similarity = max(0, 1 - (distance / 1.5))
            
            # Determine if it's a match
            is_match = distance < self.threshold
            
            logger.info(f"Distance: {distance:.4f}, Similarity: {similarity:.4f}, Match: {is_match}")
            
            return {
                "success": True,
                "similarity": float(similarity),
                "is_match": bool(is_match),
                "distance": float(distance)
            }
            
        except Exception as e:
            logger.error(f"Error comparing embeddings: {str(e)}")
            raise ValueError(f"Error comparing embeddings: {str(e)}")
    
    def _cosine_distance(self, emb1: np.ndarray, emb2: np.ndarray) -> float:
        """Calculate cosine distance between two embeddings"""
        # Normalize vectors
        emb1_norm = emb1 / np.linalg.norm(emb1)
        emb2_norm = emb2 / np.linalg.norm(emb2)
        
        # Calculate cosine similarity
        cosine_sim = np.dot(emb1_norm, emb2_norm)
        
        # Convert to distance (0 = identical, 1 = opposite)
        distance = 1 - cosine_sim
        
        return distance
    
    def detect_face(self, image_base64: str) -> Dict:
        """
        Detect if face exists in image
        
        Args:
            image_base64: Base64 encoded image string
            
        Returns:
            Dictionary with face detection status
        """
        try:
            # Decode image
            img = self._decode_base64_image(image_base64)
            
            # Detect faces
            faces = DeepFace.extract_faces(
                img_path=img,
                detector_backend=self.detector_backend,
                enforce_detection=False
            )
            
            face_detected = len(faces) > 0
            faces_count = len(faces)
            
            # Calculate confidence from first face if exists
            confidence = None
            if face_detected and len(faces) > 0:
                face_area = faces[0].get('facial_area', {})
                if face_area:
                    area = (face_area.get('w', 0) * face_area.get('h', 0))
                    confidence = min(1.0, area / (img.shape[0] * img.shape[1]) * 5)
            
            return {
                "success": True,
                "face_detected": face_detected,
                "faces_count": faces_count,
                "confidence": confidence
            }
            
        except Exception as e:
            logger.error(f"Error detecting face: {str(e)}")
            return {
                "success": True,
                "face_detected": False,
                "faces_count": 0,
                "message": str(e)
            }
    
    def verify_faces(self, img1_base64: str, img2_base64: str) -> Dict:
        """
        Verify if two images contain the same person
        
        Args:
            img1_base64: First base64 encoded image
            img2_base64: Second base64 encoded image
            
        Returns:
            Dictionary with verification result
        """
        try:
            img1 = self._decode_base64_image(img1_base64)
            img2 = self._decode_base64_image(img2_base64)
            
            result = DeepFace.verify(
                img1_path=img1,
                img2_path=img2,
                model_name=self.model_name,
                detector_backend=self.detector_backend,
                distance_metric=self.distance_metric
            )
            
            return {
                "success": True,
                "verified": result['verified'],
                "distance": result['distance'],
                "threshold": result['threshold'],
                "similarity": 1 - result['distance']
            }
            
        except Exception as e:
            logger.error(f"Error verifying faces: {str(e)}")
            return {
                "success": False,
                "message": f"Verification failed: {str(e)}"
            }
