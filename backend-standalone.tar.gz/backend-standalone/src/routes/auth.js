const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validation');
const { 
  registerSchema, 
  loginSchema, 
  faceLoginSchema,
  refreshTokenSchema,
  updateUserSchema,
  updateFaceSchema
} = require('../middleware/validation');
const { authLimiter, faceLimiter, registerLimiter } = require('../middleware/rateLimiter');

/**
 * @route   POST /api/auth/register
 * @desc    Register new user with face
 * @access  Public
 */
router.post('/register', registerLimiter, validate(registerSchema), authController.register);

/**
 * @route   POST /api/auth/login
 * @desc    Login with email and password
 * @access  Public
 */
router.post('/login', authLimiter, validate(loginSchema), authController.login);

/**
 * @route   POST /api/auth/login-face
 * @desc    Login with face recognition
 * @access  Public
 */
router.post('/login-face', faceLimiter, validate(faceLoginSchema), authController.loginWithFace);

/**
 * @route   POST /api/auth/refresh
 * @desc    Refresh access token
 * @access  Public
 */
router.post('/refresh', validate(refreshTokenSchema), authController.refreshToken);

/**
 * @route   POST /api/auth/logout
 * @desc    Logout user
 * @access  Private
 */
router.post('/logout', authenticate, authController.logout);

/**
 * @route   GET /api/auth/profile
 * @desc    Get current user profile
 * @access  Private
 */
router.get('/profile', authenticate, authController.getProfile);

/**
 * @route   PUT /api/auth/profile
 * @desc    Update user profile
 * @access  Private
 */
router.put('/profile', authenticate, validate(updateUserSchema), authController.updateProfile);

/**
 * @route   PUT /api/auth/update-face
 * @desc    Update face embedding
 * @access  Private
 */
router.put('/update-face', authenticate, faceLimiter, validate(updateFaceSchema), authController.updateFace);

module.exports = router;
