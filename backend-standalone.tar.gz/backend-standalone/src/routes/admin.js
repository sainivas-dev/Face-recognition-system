const express = require('express');
const router = express.Router();
const { authenticate, isAdmin } = require('../middleware/auth');
const adminController = require('../controllers/adminController');
const { validateObjectId } = require('../middleware/validator');

// All routes require admin authentication
router.use(authenticate);
router.use(isAdmin);

// User management
router.get('/users', adminController.getAllUsers);
router.get('/users/:id', validateObjectId('id'), adminController.getUserById);
router.put('/users/:id', validateObjectId('id'), adminController.updateUser);
router.delete('/users/:id', validateObjectId('id'), adminController.deleteUser);

// Attendance management
router.get('/attendance', adminController.getAllAttendance);
router.get('/attendance/user/:userId', validateObjectId('userId'), adminController.getUserAttendance);
router.get('/attendance/stats', adminController.getAttendanceStats);

// System stats
router.get('/stats', adminController.getSystemStats);

module.exports = router;
