const express = require('express');
const router = express.Router();
const attendanceController = require('../controllers/attendanceController');
const { authenticate, authorize } = require('../middleware/auth');
const { validate, validateParams } = require('../middleware/validation');
const { markAttendanceSchema, objectIdSchema } = require('../middleware/validation');
const { attendanceLimiter, faceLimiter } = require('../middleware/rateLimiter');

/**
 * @route   POST /api/attendance/mark
 * @desc    Mark attendance with face verification
 * @access  Private
 */
router.post('/mark', authenticate, faceLimiter, attendanceLimiter, validate(markAttendanceSchema), attendanceController.markAttendance);

/**
 * @route   POST /api/attendance/checkout
 * @desc    Mark checkout
 * @access  Private
 */
router.post('/checkout', authenticate, attendanceController.markCheckout);

/**
 * @route   GET /api/attendance/my-attendance
 * @desc    Get attendance records for current user
 * @access  Private
 */
router.get('/my-attendance', authenticate, attendanceController.getMyAttendance);

/**
 * @route   GET /api/attendance/my-summary
 * @desc    Get attendance summary for current user
 * @access  Private
 */
router.get('/my-summary', authenticate, attendanceController.getMySummary);

/**
 * @route   GET /api/attendance/today
 * @desc    Get today's attendance status
 * @access  Private
 */
router.get('/today', authenticate, attendanceController.getTodayStatus);

/**
 * @route   GET /api/attendance/all
 * @desc    Get all attendance records (Admin only)
 * @access  Private/Admin
 */
router.get('/all', authenticate, authorize('admin'), attendanceController.getAllAttendance);

/**
 * @route   GET /api/attendance/report
 * @desc    Get organization attendance report (Admin only)
 * @access  Private/Admin
 */
router.get('/report', authenticate, authorize('admin'), attendanceController.getOrganizationReport);

/**
 * @route   DELETE /api/attendance/:id
 * @desc    Delete attendance record (Admin only)
 * @access  Private/Admin
 */
router.delete('/:id', authenticate, authorize('admin'), validateParams(objectIdSchema), attendanceController.deleteAttendance);

module.exports = router;
