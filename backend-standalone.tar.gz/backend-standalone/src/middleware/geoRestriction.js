const geoip = require('geoip-lite');

// Allowed locations configuration
const ALLOWED_LOCATIONS = {
  cities: process.env.ALLOWED_CITIES ? process.env.ALLOWED_CITIES.split(',') : [],
  states: process.env.ALLOWED_STATES ? process.env.ALLOWED_STATES.split(',') : [],
  countries: process.env.ALLOWED_COUNTRIES ? process.env.ALLOWED_COUNTRIES.split(',') : ['US']
};

// Check if geo-restriction is enabled
const GEO_RESTRICTION_ENABLED = process.env.GEO_RESTRICTION_ENABLED === 'true';

/**
 * Middleware to validate request location based on IP geolocation
 */
const geoRestriction = (req, res, next) => {
  // Skip if geo-restriction is disabled
  if (!GEO_RESTRICTION_ENABLED) {
    return next();
  }

  // Get client IP address
  const clientIP = req.headers['x-forwarded-for']?.split(',')[0].trim() || 
                   req.headers['x-real-ip'] || 
                   req.connection.remoteAddress || 
                   req.socket.remoteAddress;

  // Remove IPv6 prefix if present
  const cleanIP = clientIP.replace(/^::ffff:/, '');

  // Skip validation for localhost in development
  if (cleanIP === '127.0.0.1' || cleanIP === '::1' || cleanIP === 'localhost') {
    if (process.env.NODE_ENV === 'development') {
      console.log('⚠️  Localhost detected - bypassing geo-restriction in development');
      return next();
    }
  }

  // Lookup IP geolocation
  const geo = geoip.lookup(cleanIP);

  if (!geo) {
    console.error(`❌ Geo-restriction: Unable to determine location for IP: ${cleanIP}`);
    return res.status(403).json({
      success: false,
      error: 'Access Forbidden',
      message: 'Unable to verify your location. Access is restricted.',
      code: 'GEO_LOCATION_UNKNOWN'
    });
  }

  const { city, region: state, country, ll: [latitude, longitude] } = geo;

  // Store location data in request for later use
  req.geoLocation = {
    ip: cleanIP,
    city,
    state,
    country,
    latitude,
    longitude
  };

  // Validate location
  const isAllowed = validateLocation(country, state, city);

  if (!isAllowed) {
    console.warn(`🚫 Geo-restriction blocked: ${cleanIP} - ${city}, ${state}, ${country}`);
    return res.status(403).json({
      success: false,
      error: 'Access Forbidden',
      message: `Access is restricted to specific locations. Your location: ${city}, ${state}, ${country}`,
      code: 'GEO_LOCATION_RESTRICTED',
      details: {
        detectedLocation: { city, state, country },
        allowedLocations: ALLOWED_LOCATIONS
      }
    });
  }

  console.log(`✅ Geo-restriction passed: ${cleanIP} - ${city}, ${state}, ${country}`);
  next();
};

/**
 * Validate if the location is allowed
 */
function validateLocation(country, state, city) {
  // Check country first (most restrictive)
  if (ALLOWED_LOCATIONS.countries.length > 0) {
    if (!ALLOWED_LOCATIONS.countries.includes(country)) {
      return false;
    }
  }

  // Check state if specified
  if (ALLOWED_LOCATIONS.states.length > 0) {
    const stateMatch = ALLOWED_LOCATIONS.states.some(allowedState => 
      state.toLowerCase().includes(allowedState.toLowerCase()) ||
      allowedState.toLowerCase().includes(state.toLowerCase())
    );
    if (!stateMatch) {
      return false;
    }
  }

  // Check city if specified (most specific)
  if (ALLOWED_LOCATIONS.cities.length > 0) {
    const cityMatch = ALLOWED_LOCATIONS.cities.some(allowedCity => 
      city.toLowerCase().includes(allowedCity.toLowerCase()) ||
      allowedCity.toLowerCase().includes(city.toLowerCase())
    );
    if (!cityMatch) {
      return false;
    }
  }

  return true;
}

/**
 * Admin middleware to bypass geo-restriction
 */
const bypassGeoRestriction = (req, res, next) => {
  // This can be used for admin routes or system operations
  console.log('⚡ Bypassing geo-restriction for privileged route');
  next();
};

module.exports = {
  geoRestriction,
  bypassGeoRestriction,
  validateLocation
};
