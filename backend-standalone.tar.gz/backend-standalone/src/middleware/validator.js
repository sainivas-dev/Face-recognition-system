const { body, param, query, validationResult } = require('express-validator');

/**
 * Middleware to check validation results
 */
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      error: 'Validation failed',
      errors: errors.array().map(err => ({
        field: err.param,
        message: err.msg
      }))
    });
  }
  next();
};

/**
 * Validation rules for user registration
 */
const validateRegister = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('name')
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('Name must be between 2 and 50 characters')
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage('Name can only contain letters and spaces'),
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one uppercase letter, one lowercase letter, and one number'),
  validate
];

/**
 * Validation rules for user login
 */
const validateLogin = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('password')
    .notEmpty()
    .withMessage('Password is required'),
  validate
];

/**
 * Validation rules for face registration
 */
const validateFaceRegistration = [
  body('image')
    .notEmpty()
    .withMessage('Face image is required')
    .isBase64()
    .withMessage('Image must be a valid base64 string'),
  validate
];

/**
 * Validation rules for face login
 */
const validateFaceLogin = [
  body('image')
    .notEmpty()
    .withMessage('Face image is required')
    .isBase64()
    .withMessage('Image must be a valid base64 string'),
  validate
];

/**
 * Validation rules for attendance marking
 */
const validateAttendance = [
  body('image')
    .notEmpty()
    .withMessage('Face image is required')
    .isBase64()
    .withMessage('Image must be a valid base64 string'),
  body('type')
    .isIn(['checkIn', 'checkOut'])
    .withMessage('Type must be either checkIn or checkOut'),
  validate
];

/**
 * Validation rules for MongoDB ObjectId
 */
const validateObjectId = (paramName = 'id') => [
  param(paramName)
    .isMongoId()
    .withMessage('Invalid ID format'),
  validate
];

/**
 * Validation rules for date range queries
 */
const validateDateRange = [
  query('startDate')
    .optional()
    .isISO8601()
    .withMessage('Start date must be a valid ISO 8601 date'),
  query('endDate')
    .optional()
    .isISO8601()
    .withMessage('End date must be a valid ISO 8601 date'),
  validate
];

module.exports = {
  validate,
  validateRegister,
  validateLogin,
  validateFaceRegistration,
  validateFaceLogin,
  validateAttendance,
  validateObjectId,
  validateDateRange
};
