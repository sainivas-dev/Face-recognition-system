const Joi = require('joi');

/**
 * Validate request data against Joi schema
 */
const validate = (schema) => {
  return (req, res, next) => {
    const { error, value } = schema.validate(req.body, {
      abortEarly: false,
      stripUnknown: true
    });

    if (error) {
      const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
      }));

      return res.status(400).json({
        success: false,
        error: 'Validation Error',
        message: 'Invalid input data',
        errors
      });
    }

    req.validatedData = value;
    next();
  };
};

/**
 * User registration schema
 */
const registerSchema = Joi.object({
  username: Joi.string()
    .alphanum()
    .min(3)
    .max(30)
    .required()
    .messages({
      'string.alphanum': 'Username must contain only letters and numbers',
      'string.min': 'Username must be at least 3 characters',
      'string.max': 'Username cannot exceed 30 characters',
      'any.required': 'Username is required'
    }),
  email: Joi.string()
    .email()
    .required()
    .messages({
      'string.email': 'Please provide a valid email address',
      'any.required': 'Email is required'
    }),
  password: Joi.string()
    .min(8)
    .max(128)
    .pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]'))
    .required()
    .messages({
      'string.min': 'Password must be at least 8 characters',
      'string.pattern.base': 'Password must contain uppercase, lowercase, number, and special character',
      'any.required': 'Password is required'
    }),
  fullName: Joi.string()
    .min(2)
    .max(100)
    .required()
    .messages({
      'string.min': 'Full name must be at least 2 characters',
      'any.required': 'Full name is required'
    }),
  role: Joi.string()
    .valid('user', 'admin')
    .default('user'),
  faceImage: Joi.string()
    .required()
    .messages({
      'any.required': 'Face image is required for registration'
    })
});

/**
 * Login schema
 */
const loginSchema = Joi.object({
  email: Joi.string()
    .email()
    .required(),
  password: Joi.string()
    .required()
});

/**
 * Face login schema
 */
const faceLoginSchema = Joi.object({
  email: Joi.string()
    .email()
    .required(),
  faceImage: Joi.string()
    .required()
    .messages({
      'any.required': 'Face image is required for face login'
    })
});

/**
 * Attendance mark schema
 */
const markAttendanceSchema = Joi.object({
  faceImage: Joi.string()
    .required()
    .messages({
      'any.required': 'Face image is required to mark attendance'
    }),
  notes: Joi.string()
    .max(500)
    .optional()
});

/**
 * Attendance checkout schema
 */
const checkoutSchema = Joi.object({
  attendanceId: Joi.string()
    .required()
    .messages({
      'any.required': 'Attendance ID is required'
    })
});

/**
 * Date range schema
 */
const dateRangeSchema = Joi.object({
  startDate: Joi.date()
    .required()
    .messages({
      'any.required': 'Start date is required'
    }),
  endDate: Joi.date()
    .min(Joi.ref('startDate'))
    .required()
    .messages({
      'date.min': 'End date must be after start date',
      'any.required': 'End date is required'
    })
});

/**
 * Update user schema
 */
const updateUserSchema = Joi.object({
  fullName: Joi.string()
    .min(2)
    .max(100)
    .optional(),
  email: Joi.string()
    .email()
    .optional(),
  password: Joi.string()
    .min(8)
    .max(128)
    .pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]'))
    .optional(),
  isActive: Joi.boolean()
    .optional(),
  role: Joi.string()
    .valid('user', 'admin')
    .optional()
}).min(1);

/**
 * Update face schema
 */
const updateFaceSchema = Joi.object({
  faceImage: Joi.string()
    .required()
    .messages({
      'any.required': 'Face image is required'
    }),
  currentPassword: Joi.string()
    .required()
    .messages({
      'any.required': 'Current password is required for security'
    })
});

/**
 * Refresh token schema
 */
const refreshTokenSchema = Joi.object({
  refreshToken: Joi.string()
    .required()
    .messages({
      'any.required': 'Refresh token is required'
    })
});

/**
 * Query params validation
 */
const validateQuery = (schema) => {
  return (req, res, next) => {
    const { error, value } = schema.validate(req.query, {
      abortEarly: false,
      stripUnknown: true
    });

    if (error) {
      const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
      }));

      return res.status(400).json({
        success: false,
        error: 'Validation Error',
        message: 'Invalid query parameters',
        errors
      });
    }

    req.validatedQuery = value;
    next();
  };
};

/**
 * Params validation
 */
const validateParams = (schema) => {
  return (req, res, next) => {
    const { error, value } = schema.validate(req.params, {
      abortEarly: false
    });

    if (error) {
      const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
      }));

      return res.status(400).json({
        success: false,
        error: 'Validation Error',
        message: 'Invalid URL parameters',
        errors
      });
    }

    req.validatedParams = value;
    next();
  };
};

/**
 * MongoDB ObjectId validation schema
 */
const objectIdSchema = Joi.object({
  id: Joi.string()
    .pattern(/^[0-9a-fA-F]{24}$/)
    .required()
    .messages({
      'string.pattern.base': 'Invalid ID format'
    })
});

module.exports = {
  validate,
  validateQuery,
  validateParams,
  registerSchema,
  loginSchema,
  faceLoginSchema,
  markAttendanceSchema,
  checkoutSchema,
  dateRangeSchema,
  updateUserSchema,
  updateFaceSchema,
  refreshTokenSchema,
  objectIdSchema
};
