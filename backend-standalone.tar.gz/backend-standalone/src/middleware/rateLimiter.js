const rateLimit = require('express-rate-limit');

// General API rate limiter
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: {
    success: false,
    error: 'Too many requests',
    message: 'Too many requests from this IP, please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Strict rate limiter for authentication routes
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit each IP to 5 requests per windowMs
  skipSuccessfulRequests: true, // Don't count successful requests
  message: {
    success: false,
    error: 'Too many authentication attempts',
    message: 'Too many login/registration attempts. Please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Face recognition rate limiter (more restrictive)
const faceRecognitionLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10, // Limit each IP to 10 face recognition requests per minute
  message: {
    success: false,
    error: 'Too many face recognition requests',
    message: 'Please wait before trying again.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Attendance marking rate limiter
const attendanceLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 20, // Limit attendance marking to 20 per hour per IP
  message: {
    success: false,
    error: 'Too many attendance requests',
    message: 'You have exceeded the attendance marking limit.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

module.exports = {
  apiLimiter,
  authLimiter,
  faceRecognitionLimiter,
  attendanceLimiter
};
