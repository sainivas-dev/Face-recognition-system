const axios = require('axios');
const logger = require('./logger');

class AIServiceClient {
  constructor() {
    this.baseURL = process.env.AI_SERVICE_URL || 'http://localhost:8000';
    this.timeout = 30000; // 30 seconds
    
    this.client = axios.create({
      baseURL: this.baseURL,
      timeout: this.timeout,
      headers: {
        'Content-Type': 'application/json'
      }
    });

    // Add request interceptor
    this.client.interceptors.request.use(
      (config) => {
        logger.debug('AI Service Request', {
          method: config.method,
          url: config.url
        });
        return config;
      },
      (error) => {
        logger.error('AI Service Request Error', { error: error.message });
        return Promise.reject(error);
      }
    );

    // Add response interceptor
    this.client.interceptors.response.use(
      (response) => {
        logger.debug('AI Service Response', {
          status: response.status,
          url: response.config.url
        });
        return response;
      },
      (error) => {
        logger.error('AI Service Response Error', {
          message: error.message,
          status: error.response?.status,
          data: error.response?.data
        });
        return Promise.reject(error);
      }
    );
  }

  /**
   * Extract face embedding from image
   */
  async extractEmbedding(imageBase64) {
    try {
      const response = await this.client.post('/api/extract-embedding', {
        image: imageBase64
      });

      if (response.data.success) {
        return {
          success: true,
          embedding: response.data.embedding,
          confidence: response.data.confidence
        };
      }

      throw new Error(response.data.message || 'Failed to extract embedding');
    } catch (error) {
      logger.error('Extract embedding error', { error: error.message });
      
      if (error.response?.status === 400) {
        throw new Error('No face detected in image');
      }
      
      throw new Error('AI service unavailable. Please try again later.');
    }
  }

  /**
   * Compare two face embeddings
   */
  async compareEmbeddings(embedding1, embedding2) {
    try {
      const response = await this.client.post('/api/compare-embeddings', {
        embedding1,
        embedding2
      });

      if (response.data.success) {
        return {
          success: true,
          similarity: response.data.similarity,
          isMatch: response.data.is_match,
          distance: response.data.distance
        };
      }

      throw new Error(response.data.message || 'Failed to compare embeddings');
    } catch (error) {
      logger.error('Compare embeddings error', { error: error.message });
      throw new Error('AI service unavailable. Please try again later.');
    }
  }

  /**
   * Verify face against stored embedding
   */
  async verifyFace(imageBase64, storedEmbedding) {
    try {
      // First extract embedding from new image
      const extractResult = await this.extractEmbedding(imageBase64);
      
      if (!extractResult.success) {
        return {
          success: false,
          message: 'Failed to extract face from image'
        };
      }

      // Compare with stored embedding
      const compareResult = await this.compareEmbeddings(
        extractResult.embedding,
        storedEmbedding
      );

      return {
        success: true,
        isMatch: compareResult.isMatch,
        similarity: compareResult.similarity,
        confidence: extractResult.confidence
      };
    } catch (error) {
      logger.error('Verify face error', { error: error.message });
      throw error;
    }
  }

  /**
   * Detect face in image
   */
  async detectFace(imageBase64) {
    try {
      const response = await this.client.post('/api/detect-face', {
        image: imageBase64
      });

      return {
        success: response.data.success,
        faceDetected: response.data.face_detected,
        facesCount: response.data.faces_count,
        confidence: response.data.confidence
      };
    } catch (error) {
      logger.error('Detect face error', { error: error.message });
      throw new Error('Face detection failed');
    }
  }

  /**
   * Check if AI service is healthy
   */
  async healthCheck() {
    try {
      const response = await this.client.get('/health');
      return response.data.status === 'healthy';
    } catch (error) {
      logger.error('AI service health check failed', { error: error.message });
      return false;
    }
  }

  /**
   * Get AI service info
   */
  async getInfo() {
    try {
      const response = await this.client.get('/api/info');
      return response.data;
    } catch (error) {
      logger.error('Get AI service info failed', { error: error.message });
      return null;
    }
  }
}

// Create singleton instance
const aiServiceClient = new AIServiceClient();

module.exports = aiServiceClient;
module.exports.AIServiceClient = AIServiceClient;
