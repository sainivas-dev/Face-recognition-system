const User = require('../models/User');
const aiService = require('../utils/aiService');
const { generateTokenPair, verifyRefreshToken } = require('../middleware/auth');
const logger = require('../utils/logger');

/**
 * Register new user with face embedding
 */
exports.register = async (req, res) => {
  try {
    const { username, email, password, fullName, role, faceImage } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({
      $or: [{ email }, { username }]
    });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: 'User Already Exists',
        message: existingUser.email === email 
          ? 'Email already registered' 
          : 'Username already taken'
      });
    }

    // Extract face embedding from image
    logger.info('Extracting face embedding for registration', { email });
    const embeddingResult = await aiService.extractEmbedding(faceImage);

    if (!embeddingResult.success) {
      return res.status(400).json({
        success: false,
        error: 'Face Detection Failed',
        message: 'Could not detect face in the provided image'
      });
    }

    // Check if confidence is sufficient
    const minConfidence = parseFloat(process.env.MIN_FACE_CONFIDENCE) || 0.7;
    if (embeddingResult.confidence < minConfidence) {
      return res.status(400).json({
        success: false,
        error: 'Low Face Quality',
        message: 'Face quality is too low. Please ensure good lighting and clear visibility.',
        confidence: embeddingResult.confidence
      });
    }

    // Create user with face embedding
    const user = new User({
      username,
      email,
      password,
      fullName,
      role: role || 'user',
      faceEmbedding: embeddingResult.embedding,
      metadata: {
        registrationIP: req.clientIP || req.ip,
        registrationLocation: req.geoLocation
      }
    });

    await user.save();

    logger.info('User registered successfully', {
      userId: user._id,
      email: user.email,
      username: user.username
    });

    // Generate tokens
    const tokens = generateTokenPair(user._id);

    // Save refresh token
    user.refreshToken = tokens.refreshToken;
    await user.save();

    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      data: {
        user: {
          id: user._id,
          username: user.username,
          email: user.email,
          fullName: user.fullName,
          role: user.role
        },
        tokens
      }
    });
  } catch (error) {
    logger.error('Registration error', { error: error.message });
    res.status(500).json({
      success: false,
      error: 'Registration Failed',
      message: error.message || 'An error occurred during registration'
    });
  }
};

/**
 * Traditional login with email and password
 */
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user and verify credentials
    const user = await User.findByCredentials(email, password);

    // Update last login info
    user.metadata.lastLoginIP = req.clientIP || req.ip;
    user.metadata.lastLoginLocation = req.geoLocation;
    await user.save();

    logger.info('User logged in successfully', {
      userId: user._id,
      email: user.email
    });

    // Generate tokens
    const tokens = generateTokenPair(user._id);

    // Save refresh token
    user.refreshToken = tokens.refreshToken;
    await user.save();

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        user: {
          id: user._id,
          username: user.username,
          email: user.email,
          fullName: user.fullName,
          role: user.role
        },
        tokens
      }
    });
  } catch (error) {
    logger.error('Login error', { error: error.message, email: req.body.email });
    
    res.status(401).json({
      success: false,
      error: 'Login Failed',
      message: error.message || 'Invalid credentials'
    });
  }
};

/**
 * Face-based login
 */
exports.loginWithFace = async (req, res) => {
  try {
    const { email, faceImage } = req.body;

    // Find user
    const user = await User.findOne({ email, isActive: true }).select('+faceEmbedding');

    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication Failed',
        message: 'User not found'
      });
    }

    if (user.isLocked) {
      return res.status(401).json({
        success: false,
        error: 'Account Locked',
        message: 'Account is temporarily locked due to multiple failed attempts'
      });
    }

    if (!user.faceEmbedding || user.faceEmbedding.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Face Not Registered',
        message: 'No face data registered for this account'
      });
    }

    // Verify face
    logger.info('Verifying face for login', { email });
    const verifyResult = await aiService.verifyFace(faceImage, user.faceEmbedding);

    const matchThreshold = parseFloat(process.env.FACE_MATCH_THRESHOLD) || 0.6;

    if (!verifyResult.isMatch || verifyResult.similarity < matchThreshold) {
      // Increment failed attempts
      await user.incLoginAttempts();
      
      logger.warn('Face verification failed', {
        email,
        similarity: verifyResult.similarity,
        threshold: matchThreshold
      });

      return res.status(401).json({
        success: false,
        error: 'Face Verification Failed',
        message: 'Face does not match registered face',
        similarity: verifyResult.similarity
      });
    }

    // Reset login attempts on success
    await user.resetLoginAttempts();

    // Update last login info
    user.metadata.lastLoginIP = req.clientIP || req.ip;
    user.metadata.lastLoginLocation = req.geoLocation;
    await user.save();

    logger.info('Face login successful', {
      userId: user._id,
      email: user.email,
      similarity: verifyResult.similarity
    });

    // Generate tokens
    const tokens = generateTokenPair(user._id);

    // Save refresh token
    user.refreshToken = tokens.refreshToken;
    await user.save();

    res.json({
      success: true,
      message: 'Face login successful',
      data: {
        user: {
          id: user._id,
          username: user.username,
          email: user.email,
          fullName: user.fullName,
          role: user.role
        },
        tokens,
        faceMatchConfidence: verifyResult.similarity
      }
    });
  } catch (error) {
    logger.error('Face login error', { error: error.message, email: req.body.email });
    
    res.status(500).json({
      success: false,
      error: 'Face Login Failed',
      message: error.message || 'An error occurred during face login'
    });
  }
};

/**
 * Refresh access token
 */
exports.refreshToken = async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({
        success: false,
        error: 'Token Required',
        message: 'Refresh token is required'
      });
    }

    // Verify refresh token
    const decoded = verifyRefreshToken(refreshToken);

    // Find user
    const user = await User.findById(decoded.userId).select('+refreshToken');

    if (!user || !user.isActive) {
      return res.status(401).json({
        success: false,
        error: 'Invalid Token',
        message: 'User not found or inactive'
      });
    }

    // Verify refresh token matches stored token
    if (user.refreshToken !== refreshToken) {
      return res.status(401).json({
        success: false,
        error: 'Invalid Token',
        message: 'Refresh token is invalid'
      });
    }

    // Generate new token pair
    const tokens = generateTokenPair(user._id);

    // Update refresh token
    user.refreshToken = tokens.refreshToken;
    await user.save();

    logger.info('Token refreshed', { userId: user._id });

    res.json({
      success: true,
      message: 'Token refreshed successfully',
      data: { tokens }
    });
  } catch (error) {
    logger.error('Refresh token error', { error: error.message });
    
    res.status(401).json({
      success: false,
      error: 'Token Refresh Failed',
      message: 'Invalid or expired refresh token'
    });
  }
};

/**
 * Logout user
 */
exports.logout = async (req, res) => {
  try {
    const user = await User.findById(req.userId);

    if (user) {
      // Clear refresh token
      user.refreshToken = undefined;
      await user.save();
    }

    logger.info('User logged out', { userId: req.userId });

    res.json({
      success: true,
      message: 'Logged out successfully'
    });
  } catch (error) {
    logger.error('Logout error', { error: error.message });
    
    res.status(500).json({
      success: false,
      error: 'Logout Failed',
      message: 'An error occurred during logout'
    });
  }
};

/**
 * Get current user profile
 */
exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      data: { user }
    });
  } catch (error) {
    logger.error('Get profile error', { error: error.message });
    
    res.status(500).json({
      success: false,
      error: 'Profile Fetch Failed',
      message: 'An error occurred while fetching profile'
    });
  }
};

/**
 * Update user profile
 */
exports.updateProfile = async (req, res) => {
  try {
    const { fullName, email } = req.body;
    const user = await User.findById(req.userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: 'User not found'
      });
    }

    // Check if email is being changed and is already taken
    if (email && email !== user.email) {
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.status(400).json({
          success: false,
          error: 'Email Taken',
          message: 'Email is already in use'
        });
      }
      user.email = email;
    }

    if (fullName) user.fullName = fullName;

    await user.save();

    logger.info('Profile updated', { userId: user._id });

    res.json({
      success: true,
      message: 'Profile updated successfully',
      data: { user }
    });
  } catch (error) {
    logger.error('Update profile error', { error: error.message });
    
    res.status(500).json({
      success: false,
      error: 'Update Failed',
      message: 'An error occurred while updating profile'
    });
  }
};

/**
 * Update face embedding
 */
exports.updateFace = async (req, res) => {
  try {
    const { faceImage, currentPassword } = req.body;
    const user = await User.findById(req.userId).select('+password +faceEmbedding');

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: 'User not found'
      });
    }

    // Verify current password for security
    const isPasswordValid = await user.comparePassword(currentPassword);
    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        error: 'Invalid Password',
        message: 'Current password is incorrect'
      });
    }

    // Extract new face embedding
    const embeddingResult = await aiService.extractEmbedding(faceImage);

    if (!embeddingResult.success) {
      return res.status(400).json({
        success: false,
        error: 'Face Detection Failed',
        message: 'Could not detect face in the provided image'
      });
    }

    user.faceEmbedding = embeddingResult.embedding;
    await user.save();

    logger.info('Face embedding updated', { userId: user._id });

    res.json({
      success: true,
      message: 'Face data updated successfully'
    });
  } catch (error) {
    logger.error('Update face error', { error: error.message });
    
    res.status(500).json({
      success: false,
      error: 'Update Failed',
      message: 'An error occurred while updating face data'
    });
  }
};
