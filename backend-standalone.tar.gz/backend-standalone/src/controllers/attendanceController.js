const Attendance = require('../models/Attendance');
const User = require('../models/User');
const logger = require('../utils/logger');
const axios = require('axios');

const AI_SERVICE_URL = process.env.AI_SERVICE_URL || 'http://ai-service:8000';

/**
 * Mark attendance (check-in or check-out)
 */
exports.markAttendance = async (req, res) => {
  try {
    const { image, type } = req.body;
    const userId = req.userId;

    // Verify face with AI service
    const aiResponse = await axios.post(`${AI_SERVICE_URL}/verify-face`, {
      image
    });

    if (!aiResponse.data.success) {
      return res.status(401).json({
        success: false,
        error: 'Face verification failed',
        message: aiResponse.data.message || 'Could not verify your face'
      });
    }

    // Check if verified user matches logged in user
    if (aiResponse.data.userId !== userId.toString()) {
      return res.status(401).json({
        success: false,
        error: 'Face mismatch',
        message: 'Face does not match authenticated user'
      });
    }

    const confidence = aiResponse.data.confidence;

    // Get client IP and location
    const ipAddress = req.headers['x-forwarded-for']?.split(',')[0].trim() || 
                     req.connection.remoteAddress || 
                     req.socket.remoteAddress;

    const location = req.geoLocation || {};

    // Check for existing attendance today
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const existingAttendance = await Attendance.findOne({
      userId,
      checkIn: { $gte: today }
    });

    if (type === 'checkIn') {
      if (existingAttendance && !existingAttendance.checkOut) {
        return res.status(400).json({
          success: false,
          error: 'Already checked in',
          message: 'You have already checked in today'
        });
      }

      // Create new attendance record
      const attendance = new Attendance({
        userId,
        checkIn: new Date(),
        confidence,
        ipAddress,
        location: {
          city: location.city,
          state: location.state,
          country: location.country,
          latitude: location.latitude,
          longitude: location.longitude
        },
        status: 'present'
      });

      await attendance.save();

      logger.info(`Attendance check-in: ${userId} (confidence: ${confidence})`);

      return res.status(200).json({
        success: true,
        message: 'Checked in successfully',
        data: {
          attendance: attendance,
          confidence
        }
      });
    } else if (type === 'checkOut') {
      if (!existingAttendance) {
        return res.status(400).json({
          success: false,
          error: 'No check-in found',
          message: 'You must check in before checking out'
        });
      }

      if (existingAttendance.checkOut) {
        return res.status(400).json({
          success: false,
          error: 'Already checked out',
          message: 'You have already checked out today'
        });
      }

      // Update with check-out time
      existingAttendance.checkOut = new Date();
      await existingAttendance.save();

      logger.info(`Attendance check-out: ${userId}`);

      return res.status(200).json({
        success: true,
        message: 'Checked out successfully',
        data: {
          attendance: existingAttendance,
          workDuration: existingAttendance.getWorkDuration()
        }
      });
    }

  } catch (error) {
    logger.error('Mark attendance error:', error);
    
    if (error.response) {
      return res.status(error.response.status).json({
        success: false,
        error: 'AI service error',
        message: error.response.data.message || 'Attendance marking failed'
      });
    }

    res.status(500).json({
      success: false,
      error: 'Failed to mark attendance',
      message: error.message
    });
  }
};

/**
 * Mark checkout (alternative endpoint)
 */
exports.markCheckout = async (req, res) => {
  req.body.type = 'checkOut';
  return exports.markAttendance(req, res);
};

/**
 * Get user's attendance records
 */
exports.getMyAttendance = async (req, res) => {
  try {
    const { startDate, endDate, page = 1, limit = 20 } = req.query;
    const userId = req.userId;

    let query = { userId };
    
    if (startDate || endDate) {
      query.checkIn = {};
      if (startDate) query.checkIn.$gte = new Date(startDate);
      if (endDate) query.checkIn.$lte = new Date(endDate);
    }

    const attendance = await Attendance.find(query)
      .sort({ checkIn: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const count = await Attendance.countDocuments(query);

    res.status(200).json({
      success: true,
      data: {
        attendance,
        totalPages: Math.ceil(count / limit),
        currentPage: parseInt(page),
        total: count
      }
    });
  } catch (error) {
    logger.error('Get attendance error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get attendance',
      message: error.message
    });
  }
};

/**
 * Get attendance summary
 */
exports.getMySummary = async (req, res) => {
  try {
    const userId = req.userId;
    const today = new Date();
    
    // This month
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const thisMonth = await Attendance.countDocuments({
      userId,
      checkIn: { $gte: startOfMonth }
    });

    // This week
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - today.getDay());
    startOfWeek.setHours(0, 0, 0, 0);
    
    const thisWeek = await Attendance.countDocuments({
      userId,
      checkIn: { $gte: startOfWeek }
    });

    // Total
    const total = await Attendance.countDocuments({ userId });

    res.status(200).json({
      success: true,
      data: {
        stats: {
          thisMonth,
          thisWeek,
          total
        }
      }
    });
  } catch (error) {
    logger.error('Get summary error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get summary',
      message: error.message
    });
  }
};

/**
 * Get today's attendance status
 */
exports.getTodayStatus = async (req, res) => {
  try {
    const userId = req.userId;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const attendance = await Attendance.findOne({
      userId,
      checkIn: { $gte: today }
    });

    res.status(200).json({
      success: true,
      data: {
        status: {
          checkedIn: !!attendance,
          checkedOut: attendance?.checkOut ? true : false,
          checkIn: attendance?.checkIn,
          checkOut: attendance?.checkOut
        }
      }
    });
  } catch (error) {
    logger.error('Get today status error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get today status',
      message: error.message
    });
  }
};

/**
 * Get all attendance (admin)
 */
exports.getAllAttendance = async (req, res) => {
  try {
    const { page = 1, limit = 20, startDate, endDate } = req.query;
    
    let query = {};
    if (startDate || endDate) {
      query.checkIn = {};
      if (startDate) query.checkIn.$gte = new Date(startDate);
      if (endDate) query.checkIn.$lte = new Date(endDate);
    }

    const attendance = await Attendance.find(query)
      .populate('userId', 'name email')
      .sort({ checkIn: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const count = await Attendance.countDocuments(query);

    res.status(200).json({
      success: true,
      data: {
        attendance,
        totalPages: Math.ceil(count / limit),
        currentPage: parseInt(page),
        total: count
      }
    });
  } catch (error) {
    logger.error('Get all attendance error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get attendance',
      message: error.message
    });
  }
};

/**
 * Get organization report (admin)
 */
exports.getOrganizationReport = async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const stats = {
      today: await Attendance.countDocuments({ checkIn: { $gte: today } }),
      thisWeek: await Attendance.countDocuments({ 
        checkIn: { $gte: new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000) }
      }),
      thisMonth: await Attendance.countDocuments({
        checkIn: { $gte: new Date(today.getFullYear(), today.getMonth(), 1) }
      }),
      total: await Attendance.countDocuments({})
    };

    res.status(200).json({
      success: true,
      data: { stats }
    });
  } catch (error) {
    logger.error('Get report error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get report',
      message: error.message
    });
  }
};

/**
 * Delete attendance record (admin)
 */
exports.deleteAttendance = async (req, res) => {
  try {
    const attendance = await Attendance.findByIdAndDelete(req.params.id);
    
    if (!attendance) {
      return res.status(404).json({
        success: false,
        error: 'Attendance not found'
      });
    }

    logger.info(`Attendance deleted by admin: ${req.params.id}`);

    res.status(200).json({
      success: true,
      message: 'Attendance deleted successfully'
    });
  } catch (error) {
    logger.error('Delete attendance error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete attendance',
      message: error.message
    });
  }
};
