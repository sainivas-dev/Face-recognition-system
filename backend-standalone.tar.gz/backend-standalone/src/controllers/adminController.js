const User = require('../models/User');
const Attendance = require('../models/Attendance');
const Embedding = require('../models/Embedding');
const logger = require('../utils/logger');

exports.getAllUsers = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '' } = req.query;
    
    const query = search ? {
      $or: [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ]
    } : {};

    const users = await User.find(query)
      .select('-password')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });

    const count = await User.countDocuments(query);

    res.status(200).json({
      success: true,
      data: {
        users,
        totalPages: Math.ceil(count / limit),
        currentPage: page,
        total: count
      }
    });
  } catch (error) {
    logger.error('Get all users error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get users',
      message: error.message
    });
  }
};

exports.getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      data: { user }
    });
  } catch (error) {
    logger.error('Get user error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get user',
      message: error.message
    });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { name, email, role, isActive } = req.body;
    
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { name, email, role, isActive },
      { new: true, runValidators: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    logger.info(`User updated by admin: ${user.email}`);

    res.status(200).json({
      success: true,
      message: 'User updated successfully',
      data: { user }
    });
  } catch (error) {
    logger.error('Update user error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update user',
      message: error.message
    });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Delete related data
    await Embedding.deleteOne({ userId: req.params.id });
    await Attendance.deleteMany({ userId: req.params.id });

    logger.info(`User deleted by admin: ${user.email}`);

    res.status(200).json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    logger.error('Delete user error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete user',
      message: error.message
    });
  }
};

exports.getAllAttendance = async (req, res) => {
  try {
    const { page = 1, limit = 20, startDate, endDate } = req.query;
    
    let query = {};
    if (startDate || endDate) {
      query.checkIn = {};
      if (startDate) query.checkIn.$gte = new Date(startDate);
      if (endDate) query.checkIn.$lte = new Date(endDate);
    }

    const attendance = await Attendance.find(query)
      .populate('userId', 'name email')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ checkIn: -1 });

    const count = await Attendance.countDocuments(query);

    res.status(200).json({
      success: true,
      data: {
        attendance,
        totalPages: Math.ceil(count / limit),
        currentPage: page,
        total: count
      }
    });
  } catch (error) {
    logger.error('Get attendance error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get attendance',
      message: error.message
    });
  }
};

exports.getUserAttendance = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    let query = { userId: req.params.userId };
    if (startDate || endDate) {
      query.checkIn = {};
      if (startDate) query.checkIn.$gte = new Date(startDate);
      if (endDate) query.checkIn.$lte = new Date(endDate);
    }

    const attendance = await Attendance.find(query)
      .populate('userId', 'name email')
      .sort({ checkIn: -1 });

    res.status(200).json({
      success: true,
      data: { attendance }
    });
  } catch (error) {
    logger.error('Get user attendance error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get user attendance',
      message: error.message
    });
  }
};

exports.getAttendanceStats = async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const stats = {
      today: await Attendance.countDocuments({ checkIn: { $gte: today } }),
      thisWeek: await Attendance.countDocuments({ 
        checkIn: { $gte: new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000) }
      }),
      thisMonth: await Attendance.countDocuments({
        checkIn: { $gte: new Date(today.getFullYear(), today.getMonth(), 1) }
      }),
      total: await Attendance.countDocuments({})
    };

    res.status(200).json({
      success: true,
      data: { stats }
    });
  } catch (error) {
    logger.error('Get attendance stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get attendance stats',
      message: error.message
    });
  }
};

exports.getSystemStats = async (req, res) => {
  try {
    const stats = {
      totalUsers: await User.countDocuments({}),
      activeUsers: await User.countDocuments({ isActive: true }),
      registeredFaces: await Embedding.countDocuments({}),
      totalAttendance: await Attendance.countDocuments({}),
      todayAttendance: await Attendance.countDocuments({ 
        checkIn: { $gte: new Date(new Date().setHours(0, 0, 0, 0)) }
      })
    };

    res.status(200).json({
      success: true,
      data: { stats }
    });
  } catch (error) {
    logger.error('Get system stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get system stats',
      message: error.message
    });
  }
};
