const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  checkIn: {
    type: Date,
    required: true,
    default: Date.now
  },
  checkOut: {
    type: Date
  },
  confidence: {
    type: Number,
    required: true,
    min: 0,
    max: 1
  },
  ipAddress: {
    type: String,
    required: true
  },
  location: {
    city: String,
    state: String,
    country: String,
    latitude: Number,
    longitude: Number
  },
  status: {
    type: String,
    enum: ['present', 'absent', 'partial'],
    default: 'present'
  },
  notes: {
    type: String
  }
}, {
  timestamps: true
});

// Compound index for faster queries
attendanceSchema.index({ userId: 1, checkIn: -1 });
attendanceSchema.index({ checkIn: -1 });

// Method to calculate work duration
attendanceSchema.methods.getWorkDuration = function() {
  if (!this.checkOut) return null;
  
  const duration = this.checkOut - this.checkIn;
  const hours = Math.floor(duration / (1000 * 60 * 60));
  const minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));
  
  return { hours, minutes, totalMinutes: Math.floor(duration / (1000 * 60)) };
};

module.exports = mongoose.model('Attendance', attendanceSchema);
