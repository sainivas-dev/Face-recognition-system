const mongoose = require('mongoose');

const embeddingSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  embedding: {
    type: [Number],
    required: true
  },
  model: {
    type: String,
    default: 'Facenet',
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Index for faster queries
embeddingSchema.index({ userId: 1 });

module.exports = mongoose.model('Embedding', embeddingSchema);
