#!/bin/bash

echo "================================================"
echo "  Face Recognition Backend - Startup Script"
echo "================================================"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed!${NC}"
    echo "Install from: https://nodejs.org/"
    exit 1
fi

echo -e "${GREEN}✅ Node.js $(node --version)${NC}"

# Check Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python 3 is not installed!${NC}"
    echo "Install Python 3.9+: https://www.python.org/"
    exit 1
fi

echo -e "${GREEN}✅ Python $(python3 --version)${NC}"

# Step 1: Install Dependencies
echo -e "\n${BLUE}Step 1: Installing dependencies...${NC}"

if [ ! -d "node_modules" ]; then
    echo "Installing Node.js packages..."
    npm install
else
    echo "Node modules already installed"
fi

if [ ! -d "ai-service/venv" ]; then
    echo "Setting up Python virtual environment..."
    cd ai-service
    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    deactivate
    cd ..
else
    echo "Python environment already set up"
fi

# Step 2: Configure Environment
echo -e "\n${BLUE}Step 2: Configuring environment...${NC}"

if [ ! -f ".env" ]; then
    cp .env.example .env
    echo -e "${YELLOW}⚠️  .env file created. Please edit it!${NC}"
    echo ""
    echo "Required settings:"
    echo "  JWT_SECRET - Generate with: openssl rand -base64 32"
    echo "  JWT_REFRESH_SECRET - Generate with: openssl rand -base64 32"
    echo "  MONGODB_URI - MongoDB connection string"
    echo ""
    read -p "Press Enter to continue..."
fi

# Step 3: Check MongoDB
echo -e "\n${BLUE}Step 3: Checking MongoDB...${NC}"

if command -v mongo &> /dev/null || command -v mongod &> /dev/null; then
    echo -e "${GREEN}✅ MongoDB is installed${NC}"
elif command -v docker &> /dev/null; then
    echo -e "${YELLOW}MongoDB not found. Starting with Docker...${NC}"
    docker run -d -p 27017:27017 --name mongodb-frs mongo:6.0
else
    echo -e "${RED}❌ MongoDB not found and Docker not available${NC}"
    echo "Please install MongoDB: https://www.mongodb.com/try/download/community"
    exit 1
fi

# Step 4: Start AI Service
echo -e "\n${BLUE}Step 4: Starting AI Service...${NC}"

cd ai-service
source venv/bin/activate
nohup uvicorn app.main:app --host 0.0.0.0 --port 8000 > ../logs/ai-service.log 2>&1 &
AI_PID=$!
deactivate
cd ..

echo -e "${GREEN}✅ AI Service started (PID: $AI_PID)${NC}"
echo "   Logs: logs/ai-service.log"
echo "   URL: http://localhost:8000"

# Wait for AI service to start
sleep 3

# Step 5: Start Backend
echo -e "\n${BLUE}Step 5: Starting Backend Server...${NC}"

mkdir -p logs
nohup npm start > logs/backend.log 2>&1 &
BACKEND_PID=$!

echo -e "${GREEN}✅ Backend started (PID: $BACKEND_PID)${NC}"
echo "   Logs: logs/backend.log"
echo "   URL: http://localhost:5000"

# Save PIDs
echo $AI_PID > .ai-service.pid
echo $BACKEND_PID > .backend.pid

# Wait and check
echo -e "\n${YELLOW}Waiting for services to initialize...${NC}"
sleep 5

# Test endpoints
echo -e "\n${BLUE}Testing endpoints...${NC}"

if curl -s http://localhost:5000/health > /dev/null; then
    echo -e "${GREEN}✅ Backend is responding${NC}"
else
    echo -e "${RED}❌ Backend is not responding${NC}"
fi

if curl -s http://localhost:8000/health > /dev/null; then
    echo -e "${GREEN}✅ AI Service is responding${NC}"
else
    echo -e "${RED}❌ AI Service is not responding${NC}"
fi

echo ""
echo "================================================"
echo "  🎉 Backend is running!"
echo "================================================"
echo ""
echo "Services:"
echo "  Backend API: http://localhost:5000"
echo "  AI Service:  http://localhost:8000"
echo "  Health:      http://localhost:5000/health"
echo ""
echo "View logs:"
echo "  tail -f logs/backend.log"
echo "  tail -f logs/ai-service.log"
echo ""
echo "Stop services:"
echo "  ./STOP.sh"
echo ""
