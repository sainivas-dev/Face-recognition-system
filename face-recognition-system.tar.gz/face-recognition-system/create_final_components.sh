#!/bin/bash

# Attendance Component with stub
cat > frontend/src/components/Attendance.jsx << 'EOF'
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Webcam from 'react-webcam';
import { attendanceAPI } from '../services/api';

function Attendance() {
  const navigate = useNavigate();
  const webcamRef = useRef(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [todayStatus, setTodayStatus] = useState(null);
  const [attendanceHistory, setAttendanceHistory] = useState([]);
  const [showCamera, setShowCamera] = useState(false);
  const [actionType, setActionType] = useState('checkIn');

  useEffect(() => {
    loadTodayStatus();
    loadAttendanceHistory();
  }, []);

  const loadTodayStatus = async () => {
    try {
      const response = await attendanceAPI.getTodayStatus();
      if (response.data.success) {
        setTodayStatus(response.data.data.status);
      }
    } catch (error) {
      console.error('Failed to load status:', error);
    }
  };

  const loadAttendanceHistory = async () => {
    try {
      const response = await attendanceAPI.getMyAttendance({ limit: 10 });
      if (response.data.success) {
        setAttendanceHistory(response.data.data.attendance);
      }
    } catch (error) {
      console.error('Failed to load history:', error);
    }
  };

  const handleMarkAttendance = async (type) => {
    setActionType(type);
    setShowCamera(true);
  };

  const captureAndMark = async () => {
    setMessage('');
    setLoading(true);

    try {
      const imageSrc = webcamRef.current.getScreenshot();
      if (!imageSrc) {
        setMessage('Failed to capture image');
        return;
      }

      const response = await attendanceAPI.markAttendance({
        image: imageSrc,
        type: actionType
      });

      if (response.data.success) {
        setMessage(`Successfully ${actionType === 'checkIn' ? 'checked in' : 'checked out'}!`);
        setShowCamera(false);
        loadTodayStatus();
        loadAttendanceHistory();
      }
    } catch (error) {
      setMessage(error.response?.data?.message || 'Failed to mark attendance');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <nav className="glass-effect border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <button
              onClick={() => navigate('/dashboard')}
              className="flex items-center space-x-2 text-white hover:text-gray-300 transition"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              <span>Back to Dashboard</span>
            </button>
            <h1 className="text-2xl font-bold text-white">Attendance</h1>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {message && (
          <div className={`mb-6 p-4 rounded-lg ${
            message.includes('Success') ? 'bg-green-500/20 text-green-200' : 'bg-red-500/20 text-red-200'
          }`}>
            {message}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Mark Attendance Section */}
          <div className="glass-effect rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-white mb-6">Mark Attendance</h2>
            
            {todayStatus && (
              <div className="mb-6 p-4 bg-blue-500/20 rounded-lg">
                <p className="text-blue-200 font-medium">
                  Today's Status: {todayStatus.checkedIn ? 
                    `Checked In at ${new Date(todayStatus.checkIn).toLocaleTimeString()}` :
                    'Not checked in yet'
                  }
                </p>
              </div>
            )}

            {!showCamera ? (
              <div className="space-y-4">
                <button
                  onClick={() => handleMarkAttendance('checkIn')}
                  disabled={todayStatus?.checkedIn && !todayStatus?.checkedOut}
                  className="w-full py-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-semibold rounded-lg hover:from-green-600 hover:to-emerald-700 transition disabled:opacity-50"
                >
                  Check In
                </button>
                <button
                  onClick={() => handleMarkAttendance('checkOut')}
                  disabled={!todayStatus?.checkedIn || todayStatus?.checkedOut}
                  className="w-full py-4 bg-gradient-to-r from-orange-500 to-red-600 text-white font-semibold rounded-lg hover:from-orange-600 hover:to-red-700 transition disabled:opacity-50"
                >
                  Check Out
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="rounded-lg overflow-hidden">
                  <Webcam
                    ref={webcamRef}
                    audio={false}
                    screenshotFormat="image/jpeg"
                    className="w-full rounded-lg"
                    videoConstraints={{ facingMode: 'user' }}
                  />
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={captureAndMark}
                    disabled={loading}
                    className="flex-1 py-3 bg-gradient-to-r from-purple-500 to-pink-600 text-white font-semibold rounded-lg transition disabled:opacity-50"
                  >
                    {loading ? 'Processing...' : `Capture & ${actionType === 'checkIn' ? 'Check In' : 'Check Out'}`}
                  </button>
                  <button
                    onClick={() => setShowCamera(false)}
                    className="px-6 py-3 bg-white/10 text-white rounded-lg hover:bg-white/20 transition"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Attendance History */}
          <div className="glass-effect rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-white mb-6">Recent History</h2>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {attendanceHistory.map((record) => (
                <div key={record._id} className="p-4 bg-white/5 rounded-lg">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-white font-medium">
                        {new Date(record.checkIn).toLocaleDateString()}
                      </p>
                      <p className="text-gray-400 text-sm">
                        In: {new Date(record.checkIn).toLocaleTimeString()}
                      </p>
                      {record.checkOut && (
                        <p className="text-gray-400 text-sm">
                          Out: {new Date(record.checkOut).toLocaleTimeString()}
                        </p>
                      )}
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      record.confidence > 0.8 ? 'bg-green-500/20 text-green-300' :
                      record.confidence > 0.6 ? 'bg-yellow-500/20 text-yellow-300' :
                      'bg-red-500/20 text-red-300'
                    }`}>
                      {(record.confidence * 100).toFixed(0)}% match
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Attendance;
EOF

# AdminPanel Component (stub)
cat > frontend/src/components/AdminPanel.jsx << 'EOF'
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { adminAPI } from '../services/api';

function AdminPanel() {
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [statsRes, usersRes] = await Promise.all([
        adminAPI.getSystemStats(),
        adminAPI.getAllUsers({ page: 1, limit: 20 })
      ]);

      if (statsRes.data.success) {
        setStats(statsRes.data.data.stats);
      }

      if (usersRes.data.success) {
        setUsers(usersRes.data.data.users);
      }
    } catch (error) {
      console.error('Failed to load admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <nav className="glass-effect border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <button
              onClick={() => navigate('/dashboard')}
              className="flex items-center space-x-2 text-white hover:text-gray-300 transition"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              <span>Back to Dashboard</span>
            </button>
            <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Grid */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="glass-effect rounded-xl p-6">
              <p className="text-gray-400 text-sm font-medium">Total Users</p>
              <p className="text-3xl font-bold text-white mt-1">{stats.totalUsers}</p>
            </div>
            <div className="glass-effect rounded-xl p-6">
              <p className="text-gray-400 text-sm font-medium">Active Users</p>
              <p className="text-3xl font-bold text-white mt-1">{stats.activeUsers}</p>
            </div>
            <div className="glass-effect rounded-xl p-6">
              <p className="text-gray-400 text-sm font-medium">Registered Faces</p>
              <p className="text-3xl font-bold text-white mt-1">{stats.registeredFaces}</p>
            </div>
            <div className="glass-effect rounded-xl p-6">
              <p className="text-gray-400 text-sm font-medium">Today Attendance</p>
              <p className="text-3xl font-bold text-white mt-1">{stats.todayAttendance}</p>
            </div>
          </div>
        )}

        {/* Users Table */}
        <div className="glass-effect rounded-2xl p-8">
          <h2 className="text-2xl font-bold text-white mb-6">Users</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-left py-3 px-4 text-gray-300 font-medium">Name</th>
                  <th className="text-left py-3 px-4 text-gray-300 font-medium">Email</th>
                  <th className="text-left py-3 px-4 text-gray-300 font-medium">Role</th>
                  <th className="text-left py-3 px-4 text-gray-300 font-medium">Status</th>
                  <th className="text-left py-3 px-4 text-gray-300 font-medium">Face Registered</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user._id} className="border-b border-white/5 hover:bg-white/5">
                    <td className="py-3 px-4 text-white">{user.name}</td>
                    <td className="py-3 px-4 text-gray-300">{user.email}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        user.role === 'admin' ? 'bg-purple-500/20 text-purple-300' : 'bg-blue-500/20 text-blue-300'
                      }`}>
                        {user.role}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        user.isActive ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'
                      }`}>
                        {user.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {user.faceRegistered ? (
                        <svg className="w-5 h-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      ) : (
                        <svg className="w-5 h-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                        </svg>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminPanel;
EOF

echo "✅ Final components created!"
