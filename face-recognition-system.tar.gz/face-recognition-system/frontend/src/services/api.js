import axios from 'axios';
import { getToken, logout } from '../utils/auth';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    const token = getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      logout();
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  faceLogin: (data) => api.post('/auth/face-login', data),
  registerFace: (data) => api.post('/auth/register-face', data),
  getProfile: () => api.get('/auth/profile'),
  logout: () => api.post('/auth/logout'),
};

export const attendanceAPI = {
  markAttendance: (data) => api.post('/attendance/mark', data),
  getMyAttendance: (params) => api.get('/attendance/my-attendance', { params }),
  getTodayStatus: () => api.get('/attendance/today-status'),
  getStats: () => api.get('/attendance/stats'),
};

export const adminAPI = {
  getAllUsers: (params) => api.get('/admin/users', { params }),
  getUserById: (id) => api.get(`/admin/users/${id}`),
  updateUser: (id, data) => api.put(`/admin/users/${id}`, data),
  deleteUser: (id) => api.delete(`/admin/users/${id}`),
  getAllAttendance: (params) => api.get('/admin/attendance', { params }),
  getUserAttendance: (userId, params) => api.get(`/admin/attendance/user/${userId}`, { params }),
  getSystemStats: () => api.get('/admin/stats'),
};

export default api;
