# Deployment Guide

Complete deployment instructions for the Face Recognition System.

## Pre-Deployment Checklist

- [ ] Domain name configured (if using custom domain)
- [ ] SSL/TLS certificates obtained
- [ ] MongoDB production instance ready
- [ ] Environment variables configured
- [ ] Firewall rules configured
- [ ] Geo-restriction settings finalized
- [ ] Backup strategy planned

## Production Environment Setup

### 1. Server Requirements

**Minimum Specifications:**
- CPU: 4 cores
- RAM: 8GB
- Storage: 50GB SSD
- OS: Ubuntu 22.04 LTS
- Network: 100 Mbps

**Recommended Specifications:**
- CPU: 8 cores
- RAM: 16GB
- Storage: 100GB SSD
- OS: Ubuntu 22.04 LTS
- Network: 1 Gbps

### 2. Initial Server Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y curl wget git ufw

# Configure firewall
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Reboot
sudo reboot
```

### 3. Clone and Configure

```bash
# Clone repository
git clone <your-repository-url>
cd face-recognition-system

# Create production environment files
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env

# Edit configuration files
nano backend/.env
nano frontend/.env
```

### 4. SSL Certificate Setup

#### Option A: Let's Encrypt (Free)

```bash
# Install certbot
sudo apt install certbot

# Obtain certificate
sudo certbot certonly --standalone -d yourdomain.com -d www.yourdomain.com

# Copy certificates
sudo cp /etc/letsencrypt/live/yourdomain.com/fullchain.pem nginx/ssl/cert.pem
sudo cp /etc/letsencrypt/live/yourdomain.com/privkey.pem nginx/ssl/key.pem

# Set up auto-renewal
sudo certbot renew --dry-run
```

#### Option B: Self-Signed (Development Only)

```bash
mkdir -p nginx/ssl
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout nginx/ssl/key.pem \
  -out nginx/ssl/cert.pem \
  -subj "/C=US/ST=State/L=City/O=Org/CN=localhost"
```

### 5. Production Environment Variables

Edit `backend/.env`:

```env
# Production settings
NODE_ENV=production
PORT=5000
FRONTEND_URL=https://yourdomain.com

# MongoDB (use production instance)
MONGODB_URI=mongodb://user:password@mongodb-host:27017/face_recognition?authSource=admin

# Strong JWT secrets (generate with: openssl rand -base64 32)
JWT_SECRET=<your-generated-secret-here>
JWT_REFRESH_SECRET=<your-generated-refresh-secret-here>

# AI Service
AI_SERVICE_URL=http://ai-service:8000

# Geo-Restriction (configure as needed)
GEO_RESTRICTION_ENABLED=true
ALLOWED_COUNTRIES=US
ALLOWED_STATES=California,New York,Texas
ALLOWED_CITIES=

# Logging
LOG_LEVEL=info
```

Edit `frontend/.env`:

```env
REACT_APP_API_URL=https://yourdomain.com/api
```

### 6. Build and Deploy

```bash
# Build and start services
docker-compose up -d --build

# Verify all services are running
docker-compose ps

# Check logs
docker-compose logs -f
```

### 7. Create Admin User

```bash
# Access MongoDB
docker exec -it frs-mongodb mongosh face_recognition

# Hash a password (use Node.js bcrypt or online tool)
# Example: bcrypt.hashSync("AdminPass123", 10)

# Insert admin user
db.users.insertOne({
  email: "admin@yourdomain.com",
  name: "System Administrator",
  password: "$2a$10$YourHashedPasswordHere",
  role: "admin",
  faceRegistered: false,
  isActive: true,
  createdAt: new Date(),
  updatedAt: new Date()
});
```

## AWS Deployment

### Using EC2 and RDS

1. **Launch EC2 Instance**:
   - AMI: Ubuntu 22.04 LTS
   - Instance Type: t3.large or better
   - Storage: 50GB gp3
   - Security Group:
     - SSH (22) from your IP
     - HTTP (80) from 0.0.0.0/0
     - HTTPS (443) from 0.0.0.0/0

2. **Set Up MongoDB Atlas** (recommended):
   ```bash
   # Sign up at mongodb.com/atlas
   # Create cluster
   # Get connection string
   # Update MONGODB_URI in backend/.env
   ```

3. **Configure Elastic IP**:
   ```bash
   # Allocate and associate Elastic IP to EC2 instance
   # Update DNS A record to point to Elastic IP
   ```

4. **Deploy Application**:
   ```bash
   # SSH into EC2
   ssh -i your-key.pem ubuntu@your-elastic-ip
   
   # Follow "Initial Server Setup" steps above
   ```

### Using ECS (Container Service)

1. **Create ECR Repositories**:
   ```bash
   aws ecr create-repository --repository-name frs-backend
   aws ecr create-repository --repository-name frs-frontend
   aws ecr create-repository --repository-name frs-ai-service
   ```

2. **Build and Push Images**:
   ```bash
   # Login to ECR
   aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <account-id>.dkr.ecr.us-east-1.amazonaws.com
   
   # Build and push backend
   cd backend
   docker build -t frs-backend .
   docker tag frs-backend:latest <account-id>.dkr.ecr.us-east-1.amazonaws.com/frs-backend:latest
   docker push <account-id>.dkr.ecr.us-east-1.amazonaws.com/frs-backend:latest
   
   # Repeat for frontend and ai-service
   ```

3. **Create ECS Task Definitions and Services**:
   - Use AWS Console or CloudFormation templates
   - Configure Application Load Balancer
   - Set up auto-scaling

## GCP Deployment

### Using Compute Engine

1. **Create VM Instance**:
   ```bash
   gcloud compute instances create frs-instance \
     --machine-type=n1-standard-2 \
     --boot-disk-size=50GB \
     --image-family=ubuntu-2204-lts \
     --image-project=ubuntu-os-cloud \
     --tags=http-server,https-server
   ```

2. **Configure Firewall**:
   ```bash
   gcloud compute firewall-rules create allow-http \
     --allow tcp:80 --target-tags http-server
   
   gcloud compute firewall-rules create allow-https \
     --allow tcp:443 --target-tags https-server
   ```

3. **Set Up Cloud SQL for MongoDB**:
   - Or use MongoDB Atlas
   - Update connection string

### Using Google Kubernetes Engine (GKE)

1. **Create GKE Cluster**:
   ```bash
   gcloud container clusters create frs-cluster \
     --num-nodes=3 \
     --machine-type=n1-standard-2
   ```

2. **Deploy using kubectl**:
   ```bash
   # Create namespace
   kubectl create namespace frs
   
   # Apply configurations
   kubectl apply -f k8s/ -n frs
   ```

## Docker Swarm Deployment

For multi-node deployment:

```bash
# Initialize swarm
docker swarm init

# Deploy stack
docker stack deploy -c docker-compose.yml frs

# Scale services
docker service scale frs_backend=3
docker service scale frs_ai-service=2
```

## Monitoring & Logging

### 1. Set Up Logging

```bash
# Install ELK Stack or use cloud logging
docker-compose -f docker-compose.logging.yml up -d
```

### 2. Set Up Monitoring

```bash
# Prometheus & Grafana
docker-compose -f docker-compose.monitoring.yml up -d
```

### 3. Health Checks

Create `healthcheck.sh`:
```bash
#!/bin/bash
curl -f https://yourdomain.com/health || exit 1
```

Set up cron job:
```bash
crontab -e
# Add: */5 * * * * /path/to/healthcheck.sh
```

## Backup Strategy

### 1. Database Backups

```bash
# Create backup script
cat > backup-mongodb.sh << 'EOF'
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backup/mongodb"
mkdir -p $BACKUP_DIR

docker exec frs-mongodb mongodump --out /data/backup/$DATE
docker cp frs-mongodb:/data/backup/$DATE $BACKUP_DIR/

# Upload to S3 (optional)
aws s3 sync $BACKUP_DIR s3://your-backup-bucket/mongodb/

# Clean old backups (keep 7 days)
find $BACKUP_DIR -type d -mtime +7 -exec rm -rf {} \;
EOF

chmod +x backup-mongodb.sh

# Add to crontab (daily at 2 AM)
0 2 * * * /path/to/backup-mongodb.sh
```

### 2. Application Backups

```bash
# Backup configuration and code
tar -czf frs-backup-$(date +%Y%m%d).tar.gz face-recognition-system/
```

## Scaling

### Horizontal Scaling

1. **Backend**: Multiple instances behind load balancer
2. **AI Service**: Multiple instances for face recognition
3. **Frontend**: CDN for static assets

### Load Balancer Setup

```nginx
upstream backend {
    server backend-1:5000;
    server backend-2:5000;
    server backend-3:5000;
}

upstream ai-service {
    server ai-service-1:8000;
    server ai-service-2:8000;
}
```

## Security Hardening

### 1. Server Security

```bash
# Disable root login
sudo nano /etc/ssh/sshd_config
# Set: PermitRootLogin no

# Install fail2ban
sudo apt install fail2ban
sudo systemctl enable fail2ban

# Set up automatic updates
sudo apt install unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
```

### 2. Application Security

- [ ] Use strong JWT secrets
- [ ] Enable HTTPS only
- [ ] Configure CORS properly
- [ ] Set up rate limiting
- [ ] Use secrets management (AWS Secrets Manager, etc.)
- [ ] Regular security audits
- [ ] Keep dependencies updated

### 3. Network Security

```bash
# Restrict MongoDB access
sudo ufw allow from <backend-ip> to any port 27017

# Restrict AI service access
sudo ufw allow from <backend-ip> to any port 8000
```

## Performance Tuning

### 1. Node.js Optimization

```javascript
// PM2 configuration (ecosystem.config.js)
module.exports = {
  apps: [{
    name: 'frs-backend',
    script: './src/server.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production'
    }
  }]
};
```

### 2. MongoDB Optimization

```javascript
// Create indexes
db.users.createIndex({ email: 1 });
db.embeddings.createIndex({ userId: 1 });
db.attendance.createIndex({ userId: 1, checkIn: -1 });
```

### 3. Nginx Caching

```nginx
proxy_cache_path /var/cache/nginx levels=1:2 keys_zone=my_cache:10m max_size=10g;

location /api {
    proxy_cache my_cache;
    proxy_cache_valid 200 5m;
}
```

## Troubleshooting

### Common Production Issues

1. **503 Service Unavailable**:
   - Check if services are running: `docker-compose ps`
   - Check logs: `docker-compose logs`
   - Verify network connectivity

2. **Face Recognition Slow**:
   - Increase AI service instances
   - Use faster model (OpenFace)
   - Add GPU support

3. **Database Connection Timeout**:
   - Check MongoDB status
   - Verify connection string
   - Check network latency

### Getting Help

1. Check logs: `docker-compose logs -f`
2. Review documentation
3. Contact support team
4. Open GitHub issue

## Rollback Procedure

```bash
# Stop current deployment
docker-compose down

# Restore previous version
git checkout <previous-commit>
docker-compose up -d --build

# Restore database backup if needed
docker exec frs-mongodb mongorestore /data/backup/<backup-date>
```

---

**Deployment completed successfully!** 🎉
