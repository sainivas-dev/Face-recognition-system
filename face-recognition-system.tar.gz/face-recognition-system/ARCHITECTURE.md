# Face Recognition System - Architecture & API Documentation

## System Architecture

### High-Level Architecture
```
┌──────────────────────────────────────────────────────────────┐
│                     Client Browser                            │
│               (React + Tailwind CSS)                          │
└────────────────────────┬─────────────────────────────────────┘
                         │ HTTPS
                         ▼
┌──────────────────────────────────────────────────────────────┐
│                  Nginx Reverse Proxy                          │
│           - SSL Termination                                   │
│           - Rate Limiting                                     │
│           - Load Balancing                                    │
└────┬─────────────────────────────────────────┬───────────────┘
     │                                         │
     │ /api/*                                  │ /*
     ▼                                         ▼
┌─────────────────────────────┐    ┌──────────────────────┐
│  Node.js Backend (Express)  │    │  React Frontend      │
│  - JWT Authentication       │    │  (Static Files)      │
│  - Geo-Restriction          │    └──────────────────────┘
│  - Rate Limiting            │
│  - Input Validation         │
│  - Business Logic           │
└────┬────────────────┬───────┘
     │                │
     │                │ HTTP
     │                ▼
     │       ┌──────────────────────┐
     │       │  Python AI Service   │
     │       │  (FastAPI + DeepFace)│
     │       │  - Face Detection    │
     │       │  - Embedding Extract │
     │       │  - Face Comparison   │
     │       └──────────────────────┘
     │
     │ MongoDB Protocol
     ▼
┌──────────────────────────────┐
│        MongoDB 6.0           │
│  Collections:                │
│  - users                     │
│  - attendances               │
└──────────────────────────────┘
```

### Component Details

#### 1. Frontend (React.js)
**Technology Stack:**
- React 18
- Tailwind CSS 3
- React Router v6
- react-webcam
- Axios

**Features:**
- User registration with webcam capture
- Face-based login
- Attendance marking
- User dashboard
- Admin panel

**Key Components:**
- `Login.jsx` - Authentication page
- `Register.jsx` - User registration with face capture
- `Dashboard.jsx` - User dashboard
- `AttendanceMark.jsx` - Mark attendance with face
- `AdminPanel.jsx` - Admin management
- `WebcamCapture.jsx` - Reusable webcam component

#### 2. Backend API (Node.js/Express)
**Technology Stack:**
- Node.js 18
- Express 4
- Mongoose (MongoDB ODM)
- JWT for authentication
- bcryptjs for password hashing
- geoip-lite for geo-restriction

**Middleware Stack:**
1. **Security Layer**
   - Helmet.js (Security headers)
   - CORS (Cross-origin)
   - express-mongo-sanitize (NoSQL injection)

2. **Geo-Restriction Layer**
   - IP extraction (X-Forwarded-For support)
   - GeoIP lookup
   - Country/State/City filtering
   - IP whitelist support

3. **Authentication Layer**
   - JWT verification
   - Role-based access control
   - Token refresh mechanism

4. **Rate Limiting Layer**
   - General API: 100 req/15min
   - Auth endpoints: 5 req/15min
   - Face recognition: 10 req/5min
   - Registration: 3 req/hour

5. **Validation Layer**
   - Request body validation (Joi)
   - Query parameter validation
   - URL parameter validation

**API Endpoints:**

```
Authentication:
POST   /api/auth/register          - Register with face
POST   /api/auth/login             - Traditional login
POST   /api/auth/login-face        - Face-based login
POST   /api/auth/refresh           - Refresh access token
POST   /api/auth/logout            - Logout
GET    /api/auth/profile           - Get user profile
PUT    /api/auth/profile           - Update profile
PUT    /api/auth/update-face       - Update face embedding

Attendance:
POST   /api/attendance/mark        - Mark attendance with face
POST   /api/attendance/checkout    - Mark checkout
GET    /api/attendance/my-attendance - Get user attendance
GET    /api/attendance/my-summary  - Get user summary
GET    /api/attendance/today       - Today's status
GET    /api/attendance/all         - All attendance (Admin)
GET    /api/attendance/report      - Organization report (Admin)
DELETE /api/attendance/:id         - Delete record (Admin)
```

#### 3. AI Service (Python/FastAPI)
**Technology Stack:**
- Python 3.10
- FastAPI
- DeepFace library
- OpenCV
- TensorFlow

**Face Recognition Models:**
- **Facenet512** (Default) - 512-dimensional embeddings
- VGG-Face - Alternative model
- ArcFace - High accuracy option

**Detection Backends:**
- OpenCV (Default) - Fast, CPU-friendly
- RetinaFace - Higher accuracy
- MTCNN - Multi-task CNN

**API Endpoints:**

```
GET    /health                     - Health check
GET    /api/info                   - Service information
POST   /api/extract-embedding      - Extract face embedding
POST   /api/compare-embeddings     - Compare two embeddings
POST   /api/detect-face            - Detect face in image
POST   /api/verify-face            - Verify face against embedding
```

**Embedding Process:**
1. Receive base64 image
2. Decode to numpy array
3. Detect face using detector backend
4. Extract face region
5. Generate 512-dim embedding using Facenet512
6. Return embedding + confidence score

**Comparison Process:**
1. Receive two embeddings
2. Calculate cosine distance
3. Compare against threshold (default: 0.4)
4. Return similarity score + match status

#### 4. Database (MongoDB)
**Collections Schema:**

**users:**
```javascript
{
  _id: ObjectId,
  username: String (unique, indexed),
  email: String (unique, indexed),
  password: String (hashed),
  fullName: String,
  role: String (enum: 'user', 'admin'),
  faceEmbedding: [Number] (512-dim array),
  isActive: Boolean,
  isVerified: Boolean,
  loginAttempts: Number,
  lockUntil: Date,
  lastLogin: Date,
  refreshToken: String,
  metadata: {
    registrationIP: String,
    registrationLocation: {
      country: String,
      region: String,
      city: String
    },
    lastLoginIP: String,
    lastLoginLocation: Object
  },
  createdAt: Date,
  updatedAt: Date
}
```

**attendances:**
```javascript
{
  _id: ObjectId,
  user: ObjectId (ref: User, indexed),
  date: Date (indexed),
  checkInTime: Date,
  checkOutTime: Date,
  status: String (enum: 'present', 'absent', 'late', 'half-day', 'leave'),
  faceMatchConfidence: Number (0-1),
  location: {
    ip: String,
    country: String,
    region: String,
    city: String
  },
  deviceInfo: {
    userAgent: String,
    platform: String,
    browser: String
  },
  notes: String,
  isManualEntry: Boolean,
  workDuration: Number (minutes),
  createdAt: Date,
  updatedAt: Date
}
```

**Indexes:**
- users: email, username, isActive, createdAt
- attendances: user+date (compound), status+date, createdAt

### Geo-Restriction Implementation

**IP Extraction:**
```
1. Check X-Forwarded-For header (proxy/load balancer)
2. Check X-Real-IP header
3. Fallback to req.ip (direct connection)
4. Normalize IPv6 to IPv4 if needed
```

**Location Determination:**
```
1. Extract IP address
2. Check IP whitelist (bypass geo-restriction)
3. Detect local/private IPs (always allow)
4. Lookup IP in GeoIP database
5. Extract country, region, city
6. Compare against allowed lists
7. Return 403 if not allowed
```

**Configuration Modes:**
- **strict**: Deny if geolocation fails
- **moderate**: Allow if geolocation fails
- **disabled**: No geo-restriction

### Security Features

#### 1. Authentication Security
- JWT with short expiry (15 minutes)
- Refresh tokens (7 days)
- Account lockout after 5 failed attempts
- Password requirements: 8+ chars, mixed case, numbers, symbols
- No plaintext passwords stored

#### 2. Face Recognition Security
- No raw images stored (only embeddings)
- Minimum confidence threshold (0.7)
- Match threshold configurable (default: 0.6)
- Face quality validation

#### 3. API Security
- Rate limiting per endpoint
- Input validation and sanitization
- MongoDB injection prevention
- Security headers (Helmet.js)
- CORS properly configured

#### 4. Network Security
- Geo-restriction by IP
- IP whitelist support
- HTTPS/TLS encryption
- Nginx reverse proxy

### Scalability Considerations

**Horizontal Scaling:**
- Backend: Stateless, can run multiple instances
- AI Service: GPU instances for better performance
- MongoDB: Replica sets for high availability
- Nginx: Load balancer for distribution

**Caching Strategy:**
- Redis for session storage (optional)
- API response caching
- Face embedding caching

**Performance Optimization:**
- Database indexes
- Image compression
- Lazy loading
- Connection pooling

### Monitoring & Logging

**Application Logs:**
- Winston logger
- Log levels: error, warn, info, debug
- Structured logging (JSON format)
- Rotation policy (5MB files, 5 backups)

**Metrics to Monitor:**
- API response times
- Face recognition accuracy
- Authentication success/failure rates
- Database query performance
- Memory and CPU usage

**Health Checks:**
- Backend: `/health`
- AI Service: `/health`
- MongoDB: Connection status
- Nginx: Server status

### Deployment Architecture

**Development:**
```
Docker Compose on local machine
- Easy setup
- Hot reload
- Debug mode
```

**Staging:**
```
Single EC2/VM instance
- Docker Compose
- SSL with Let's Encrypt
- Automated backups
```

**Production:**
```
Option 1: AWS
- EC2 Auto Scaling Group
- Application Load Balancer
- RDS MongoDB / DocumentDB
- S3 for backups
- CloudWatch monitoring

Option 2: Kubernetes
- GKE / EKS / AKS
- Horizontal Pod Autoscaler
- Persistent volumes for MongoDB
- Ingress controller
```

### API Response Formats

**Success Response:**
```json
{
  "success": true,
  "message": "Operation successful",
  "data": { }
}
```

**Error Response:**
```json
{
  "success": false,
  "error": "Error Type",
  "message": "Human readable message",
  "errors": [ ]  // Validation errors
}
```

### Rate Limit Headers:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1640000000
```

## Testing

**Unit Tests:**
- Backend controllers
- Middleware functions
- Database models

**Integration Tests:**
- API endpoints
- Authentication flow
- Face recognition pipeline

**Load Tests:**
- Apache Bench
- Artillery
- k6

## Maintenance

**Regular Tasks:**
- Database backups (daily)
- Log rotation
- Security updates
- Dependency updates
- Performance monitoring

**Disaster Recovery:**
- Database backup strategy
- Failover procedures
- Recovery time objective (RTO)
- Recovery point objective (RPO)
