# Face Recognition System - Complete File Structure

```
face-recognition-system/
│
├── README.md                          # Main project documentation
├── QUICKSTART.md                      # Quick start guide
├── DEPLOYMENT.md                      # Deployment instructions
├── ARCHITECTURE.md                    # System architecture details
├── LICENSE                            # MIT License
│
├── backend/                           # Node.js Express Backend
│   ├── src/
│   │   ├── config/
│   │   │   └── database.js           # MongoDB configuration
│   │   ├── controllers/
│   │   │   ├── authController.js     # Authentication logic
│   │   │   ├── attendanceController.js # Attendance management
│   │   │   └── adminController.js    # Admin operations
│   │   ├── middleware/
│   │   │   ├── auth.js               # JWT authentication
│   │   │   ├── geoRestriction.js     # Geo-restriction logic
│   │   │   ├── rateLimiter.js        # Rate limiting
│   │   │   ├── validation.js         # Input validation schemas
│   │   │   └── validator.js          # Custom validators
│   │   ├── models/
│   │   │   ├── User.js               # User schema
│   │   │   ├── Attendance.js         # Attendance schema
│   │   │   └── Embedding.js          # Embedding storage schema
│   │   ├── routes/
│   │   │   ├── auth.js               # Auth routes
│   │   │   ├── attendance.js         # Attendance routes
│   │   │   └── admin.js              # Admin routes
│   │   ├── utils/
│   │   │   ├── logger.js             # Winston logger
│   │   │   ├── aiService.js          # AI service client
│   │   │   └── jwt.js                # JWT utilities
│   │   └── server.js                 # Main Express app
│   ├── logs/                          # Application logs
│   ├── package.json                   # Dependencies
│   ├── Dockerfile                     # Docker configuration
│   └── .env.example                   # Environment template
│
├── ai-service/                        # Python FastAPI AI Service
│   ├── app/
│   │   ├── main.py                   # FastAPI application
│   │   ├── face_service.py           # Face recognition logic
│   │   └── models.py                 # Pydantic models
│   ├── requirements.txt               # Python dependencies
│   ├── Dockerfile                     # Docker configuration
│   └── .env.example                   # Environment template
│
├── frontend/                          # React.js Frontend
│   ├── public/
│   │   ├── index.html                # HTML template
│   │   └── favicon.ico               # Favicon
│   ├── src/
│   │   ├── components/
│   │   │   ├── common/
│   │   │   │   ├── Navbar.jsx        # Navigation bar
│   │   │   │   ├── Footer.jsx        # Footer component
│   │   │   │   └── Loader.jsx        # Loading spinner
│   │   │   ├── auth/
│   │   │   │   ├── Login.jsx         # Login page
│   │   │   │   ├── Register.jsx      # Registration page
│   │   │   │   └── WebcamCapture.jsx # Webcam component
│   │   │   ├── attendance/
│   │   │   │   ├── MarkAttendance.jsx # Mark attendance
│   │   │   │   ├── AttendanceList.jsx # View records
│   │   │   │   └── AttendanceSummary.jsx # Summary stats
│   │   │   ├── dashboard/
│   │   │   │   ├── Dashboard.jsx     # User dashboard
│   │   │   │   └── Profile.jsx       # User profile
│   │   │   └── admin/
│   │   │       ├── AdminPanel.jsx    # Admin dashboard
│   │   │       ├── UserManagement.jsx # Manage users
│   │   │       └── Reports.jsx       # Generate reports
│   │   ├── context/
│   │   │   └── AuthContext.jsx       # Authentication context
│   │   ├── services/
│   │   │   └── api.js                # API client (Axios)
│   │   ├── utils/
│   │   │   ├── auth.js               # Auth utilities
│   │   │   └── constants.js          # App constants
│   │   ├── App.js                     # Main App component
│   │   ├── index.js                   # React entry point
│   │   └── index.css                  # Global styles
│   ├── package.json                   # Dependencies
│   ├── tailwind.config.js             # Tailwind configuration
│   ├── Dockerfile                     # Docker configuration
│   ├── nginx.conf                     # Nginx for serving
│   └── .env.example                   # Environment template
│
├── nginx/                             # Nginx Reverse Proxy
│   ├── nginx.conf                     # Main configuration
│   └── ssl/                           # SSL certificates
│       ├── cert.pem                   # SSL certificate
│       └── key.pem                    # SSL private key
│
├── deployment/                        # Deployment Configurations
│   ├── docker-compose.yml             # Docker Compose setup
│   ├── docker-compose.prod.yml        # Production setup
│   ├── kubernetes/                    # Kubernetes manifests
│   │   ├── namespace.yaml
│   │   ├── mongodb-statefulset.yaml
│   │   ├── backend-deployment.yaml
│   │   ├── ai-service-deployment.yaml
│   │   ├── frontend-deployment.yaml
│   │   ├── services.yaml
│   │   └── ingress.yaml
│   └── terraform/                     # Infrastructure as Code
│       ├── main.tf
│       ├── variables.tf
│       └── outputs.tf
│
├── scripts/                           # Utility Scripts
│   ├── setup.sh                       # Initial setup
│   ├── backup.sh                      # Database backup
│   ├── restore.sh                     # Database restore
│   └── create-admin.js                # Create admin user
│
├── docs/                              # Additional Documentation
│   ├── API.md                         # API documentation
│   ├── SECURITY.md                    # Security guidelines
│   ├── CONTRIBUTING.md                # Contribution guide
│   └── images/                        # Documentation images
│
└── .gitignore                         # Git ignore rules
```

## Key Files Description

### Backend Files

**src/server.js**
- Main Express application
- Middleware setup
- Route mounting
- Error handling
- Database connection

**src/middleware/geoRestriction.js**
- IP extraction and normalization
- GeoIP lookup using geoip-lite
- Location validation (country/state/city)
- IP whitelist support
- CIDR range matching

**src/middleware/auth.js**
- JWT token verification
- User authentication
- Role-based authorization
- Token generation (access + refresh)

**src/middleware/rateLimiter.js**
- API rate limiting (100 req/15min)
- Auth rate limiting (5 req/15min)
- Face recognition limiting (10 req/5min)
- Registration limiting (3 req/hour)

**src/controllers/authController.js**
- User registration with face embedding
- Traditional login (email + password)
- Face-based login
- Token refresh
- Profile management
- Face embedding updates

**src/controllers/attendanceController.js**
- Mark attendance with face verification
- Checkout marking
- Attendance records retrieval
- Summary generation
- Admin reports

**src/models/User.js**
- User schema with embedded face vector
- Password hashing (bcrypt)
- Login attempt tracking
- Account locking mechanism
- Metadata storage (IP, location)

**src/models/Attendance.js**
- Attendance record schema
- Auto-status determination
- Work duration calculation
- Aggregation methods
- Location tracking

**src/utils/aiService.js**
- HTTP client for AI service
- Embedding extraction wrapper
- Face comparison wrapper
- Error handling
- Request/response logging

### AI Service Files

**app/main.py**
- FastAPI application setup
- CORS configuration
- API endpoints
- Error handlers
- Health checks

**app/face_service.py**
- DeepFace integration
- Face embedding extraction (512-dim)
- Cosine similarity calculation
- Face detection
- Image preprocessing
- Base64 encoding/decoding

### Frontend Files

**src/App.js**
- Main application component
- Routing setup (React Router)
- Authentication context provider
- Protected routes

**src/components/auth/Login.jsx**
- Email + password login form
- Face-based login option
- Error handling
- Redirect after login

**src/components/auth/Register.jsx**
- Registration form
- Webcam integration
- Face capture
- Form validation
- API integration

**src/components/auth/WebcamCapture.jsx**
- Reusable webcam component
- Image capture functionality
- Base64 conversion
- Error handling

**src/components/attendance/MarkAttendance.jsx**
- Face capture for attendance
- Real-time verification
- Success/error feedback
- Location detection

**src/services/api.js**
- Axios instance configuration
- Request interceptors (add JWT)
- Response interceptors (handle errors)
- API endpoints wrapper

### Configuration Files

**backend/.env.example**
- All backend environment variables
- MongoDB connection string
- JWT secrets
- Geo-restriction settings
- Security settings
- Feature flags

**ai-service/.env.example**
- Face recognition model selection
- Detector backend configuration
- Threshold settings

**deployment/docker-compose.yml**
- Multi-container setup
- Service dependencies
- Network configuration
- Volume management
- Health checks

**nginx/nginx.conf**
- Reverse proxy configuration
- SSL/TLS setup
- Rate limiting
- Load balancing
- Security headers

## Environment Variables

### Backend (.env)
```env
# Server
NODE_ENV=production
PORT=5000
MONGO_URI=mongodb://...

# JWT
JWT_SECRET=...
JWT_REFRESH_SECRET=...
JWT_EXPIRE=15m
JWT_REFRESH_EXPIRE=7d

# AI Service
AI_SERVICE_URL=http://ai-service:8000

# Geo-Restriction
ENABLE_GEO_RESTRICTION=true
ALLOWED_COUNTRIES=US,CA,GB,IN
ALLOWED_STATES=CA,NY,TX
ALLOWED_CITIES=San Francisco,Mumbai
IP_WHITELIST=127.0.0.1,::1

# Security
BCRYPT_SALT_ROUNDS=12
MAX_LOGIN_ATTEMPTS=5
LOCK_TIME=15

# CORS
ALLOWED_ORIGINS=http://localhost:3000
CORS_CREDENTIALS=true

# Face Recognition
MIN_FACE_CONFIDENCE=0.7
FACE_MATCH_THRESHOLD=0.6
```

### AI Service (.env)
```env
FACE_MODEL=Facenet512
DETECTOR_BACKEND=opencv
FACE_MATCH_THRESHOLD=0.4
```

### Frontend (.env)
```env
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_ENABLE_FACE_LOGIN=true
```

## Docker Configuration

### Backend Dockerfile
- Base: node:18-alpine
- Production dependencies only
- Logs directory creation
- Health check endpoint
- Port 5000 exposed

### AI Service Dockerfile
- Base: python:3.10-slim
- System dependencies (OpenCV, etc.)
- Python packages installation
- Port 8000 exposed
- Uvicorn server

### Frontend Dockerfile
- Multi-stage build
- Build stage: node:18-alpine
- Production stage: nginx:alpine
- Static file serving
- Port 80 exposed

## Database Schema

### users Collection
- Stores user credentials
- Embedded 512-dim face vectors
- Login tracking
- Role-based access

### attendances Collection
- Daily attendance records
- Face match confidence
- Location metadata
- Work duration calculation

## Security Implementation

### Authentication Flow
1. User provides credentials
2. Backend validates
3. Extract face embedding (AI service)
4. Compare with stored embedding
5. Generate JWT tokens
6. Return tokens to client

### Geo-Restriction Flow
1. Extract client IP
2. Check IP whitelist (bypass if found)
3. Normalize IP address
4. GeoIP lookup
5. Extract location data
6. Validate against allowed lists
7. Allow/deny request

### Rate Limiting Strategy
- Different limits per endpoint type
- Token bucket algorithm
- Per-IP tracking
- Redis support (optional)

## Deployment Options

### Development
- Docker Compose on localhost
- Hot reload enabled
- Debug mode
- Sample data

### Staging
- Single VPS/EC2
- Docker Compose
- Let's Encrypt SSL
- Automated backups

### Production
- Kubernetes cluster
- Horizontal scaling
- Load balancer
- Managed MongoDB
- CI/CD pipeline
- Monitoring stack
