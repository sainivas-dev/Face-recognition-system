const Attendance = require('../models/Attendance');
const User = require('../models/User');
const aiService = require('../utils/aiService');
const logger = require('../utils/logger');

/**
 * Mark attendance with face verification
 */
exports.markAttendance = async (req, res) => {
  try {
    const { faceImage, notes } = req.body;
    const userId = req.userId;

    // Check if already marked attendance today
    const hasMarked = await Attendance.hasMarkedToday(userId);
    if (hasMarked) {
      return res.status(400).json({
        success: false,
        error: 'Already Marked',
        message: 'Attendance already marked for today'
      });
    }

    // Get user with face embedding
    const user = await User.findById(userId).select('+faceEmbedding');

    if (!user || !user.faceEmbedding || user.faceEmbedding.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No Face Data',
        message: 'No face data registered for your account'
      });
    }

    // Verify face
    logger.info('Verifying face for attendance', { userId });
    const verifyResult = await aiService.verifyFace(faceImage, user.faceEmbedding);

    const matchThreshold = parseFloat(process.env.FACE_MATCH_THRESHOLD) || 0.6;

    if (!verifyResult.isMatch || verifyResult.similarity < matchThreshold) {
      logger.warn('Face verification failed for attendance', {
        userId,
        similarity: verifyResult.similarity
      });

      return res.status(401).json({
        success: false,
        error: 'Face Verification Failed',
        message: 'Face does not match registered face',
        similarity: verifyResult.similarity
      });
    }

    // Determine status based on time
    const checkInTime = new Date();
    const hour = checkInTime.getHours();
    let status = 'present';

    // Example business logic: Late if after 9:30 AM
    if (hour > 9 || (hour === 9 && checkInTime.getMinutes() > 30)) {
      status = 'late';
    }

    // Create attendance record
    const attendance = new Attendance({
      user: userId,
      date: new Date(),
      checkInTime,
      status,
      faceMatchConfidence: verifyResult.similarity,
      location: {
        ip: req.clientIP || req.ip,
        country: req.geoLocation?.country,
        region: req.geoLocation?.region,
        city: req.geoLocation?.city
      },
      deviceInfo: {
        userAgent: req.headers['user-agent'],
        platform: req.headers['sec-ch-ua-platform'],
        browser: req.headers['sec-ch-ua']
      },
      notes: notes || ''
    });

    await attendance.save();

    logger.info('Attendance marked successfully', {
      userId,
      attendanceId: attendance._id,
      status,
      confidence: verifyResult.similarity
    });

    res.status(201).json({
      success: true,
      message: 'Attendance marked successfully',
      data: {
        attendance: {
          id: attendance._id,
          date: attendance.date,
          checkInTime: attendance.checkInTime,
          status: attendance.status,
          confidence: attendance.faceMatchConfidence
        }
      }
    });
  } catch (error) {
    logger.error('Mark attendance error', { error: error.message, userId: req.userId });
    
    res.status(500).json({
      success: false,
      error: 'Attendance Marking Failed',
      message: error.message || 'An error occurred while marking attendance'
    });
  }
};

/**
 * Mark checkout
 */
exports.markCheckout = async (req, res) => {
  try {
    const userId = req.userId;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Find today's attendance record
    const attendance = await Attendance.findOne({
      user: userId,
      date: today,
      checkOutTime: { $exists: false }
    });

    if (!attendance) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: 'No active attendance record found for today'
      });
    }

    // Mark checkout
    await attendance.markCheckout();

    logger.info('Checkout marked', {
      userId,
      attendanceId: attendance._id,
      workHours: attendance.workHours
    });

    res.json({
      success: true,
      message: 'Checkout marked successfully',
      data: {
        attendance: {
          id: attendance._id,
          checkInTime: attendance.checkInTime,
          checkOutTime: attendance.checkOutTime,
          workHours: attendance.workHours,
          workDuration: attendance.workDuration
        }
      }
    });
  } catch (error) {
    logger.error('Mark checkout error', { error: error.message, userId: req.userId });
    
    res.status(500).json({
      success: false,
      error: 'Checkout Failed',
      message: 'An error occurred while marking checkout'
    });
  }
};

/**
 * Get attendance records for current user
 */
exports.getMyAttendance = async (req, res) => {
  try {
    const userId = req.userId;
    const { startDate, endDate, page = 1, limit = 20 } = req.query;

    const query = { user: userId };

    if (startDate || endDate) {
      query.date = {};
      if (startDate) query.date.$gte = new Date(startDate);
      if (endDate) query.date.$lte = new Date(endDate);
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [records, total] = await Promise.all([
      Attendance.find(query)
        .sort({ date: -1 })
        .limit(parseInt(limit))
        .skip(skip),
      Attendance.countDocuments(query)
    ]);

    res.json({
      success: true,
      data: {
        records,
        pagination: {
          total,
          page: parseInt(page),
          limit: parseInt(limit),
          pages: Math.ceil(total / parseInt(limit))
        }
      }
    });
  } catch (error) {
    logger.error('Get attendance error', { error: error.message, userId: req.userId });
    
    res.status(500).json({
      success: false,
      error: 'Fetch Failed',
      message: 'An error occurred while fetching attendance records'
    });
  }
};

/**
 * Get attendance summary for current user
 */
exports.getMySummary = async (req, res) => {
  try {
    const userId = req.userId;
    const { startDate, endDate } = req.query;

    const start = startDate ? new Date(startDate) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const end = endDate ? new Date(endDate) : new Date();

    const summary = await Attendance.getUserSummary(userId, start, end);

    // Calculate totals
    const totals = {
      present: 0,
      absent: 0,
      late: 0,
      halfDay: 0,
      leave: 0,
      totalDays: 0,
      totalWorkHours: 0,
      avgConfidence: 0
    };

    summary.forEach(item => {
      totals.totalDays += item.count;
      totals.totalWorkHours += item.totalWorkDuration / 60; // Convert to hours
      
      if (item._id === 'present') totals.present = item.count;
      else if (item._id === 'late') totals.late = item.count;
      else if (item._id === 'absent') totals.absent = item.count;
      else if (item._id === 'half-day') totals.halfDay = item.count;
      else if (item._id === 'leave') totals.leave = item.count;
    });

    // Calculate average confidence
    const totalConfidence = summary.reduce((sum, item) => sum + (item.avgConfidence * item.count), 0);
    totals.avgConfidence = totals.totalDays > 0 ? totalConfidence / totals.totalDays : 0;

    res.json({
      success: true,
      data: {
        period: { startDate: start, endDate: end },
        summary: totals,
        breakdown: summary
      }
    });
  } catch (error) {
    logger.error('Get summary error', { error: error.message, userId: req.userId });
    
    res.status(500).json({
      success: false,
      error: 'Summary Failed',
      message: 'An error occurred while generating summary'
    });
  }
};

/**
 * Get today's status
 */
exports.getTodayStatus = async (req, res) => {
  try {
    const userId = req.userId;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const attendance = await Attendance.findOne({
      user: userId,
      date: today
    });

    res.json({
      success: true,
      data: {
        hasMarkedToday: !!attendance,
        attendance: attendance || null
      }
    });
  } catch (error) {
    logger.error('Get today status error', { error: error.message, userId: req.userId });
    
    res.status(500).json({
      success: false,
      error: 'Status Check Failed',
      message: 'An error occurred while checking today\'s status'
    });
  }
};

/**
 * Get all attendance records (Admin only)
 */
exports.getAllAttendance = async (req, res) => {
  try {
    const { startDate, endDate, userId, status, page = 1, limit = 50 } = req.query;

    const query = {};

    if (startDate || endDate) {
      query.date = {};
      if (startDate) query.date.$gte = new Date(startDate);
      if (endDate) query.date.$lte = new Date(endDate);
    }

    if (userId) query.user = userId;
    if (status) query.status = status;

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [records, total] = await Promise.all([
      Attendance.find(query)
        .populate('user', 'username email fullName')
        .sort({ date: -1, checkInTime: -1 })
        .limit(parseInt(limit))
        .skip(skip),
      Attendance.countDocuments(query)
    ]);

    res.json({
      success: true,
      data: {
        records,
        pagination: {
          total,
          page: parseInt(page),
          limit: parseInt(limit),
          pages: Math.ceil(total / parseInt(limit))
        }
      }
    });
  } catch (error) {
    logger.error('Get all attendance error', { error: error.message });
    
    res.status(500).json({
      success: false,
      error: 'Fetch Failed',
      message: 'An error occurred while fetching attendance records'
    });
  }
};

/**
 * Get organization report (Admin only)
 */
exports.getOrganizationReport = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;

    const start = startDate ? new Date(startDate) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const end = endDate ? new Date(endDate) : new Date();

    const report = await Attendance.getOrganizationReport(start, end);

    res.json({
      success: true,
      data: {
        period: { startDate: start, endDate: end },
        report
      }
    });
  } catch (error) {
    logger.error('Get organization report error', { error: error.message });
    
    res.status(500).json({
      success: false,
      error: 'Report Generation Failed',
      message: 'An error occurred while generating report'
    });
  }
};

/**
 * Delete attendance record (Admin only)
 */
exports.deleteAttendance = async (req, res) => {
  try {
    const { id } = req.params;

    const attendance = await Attendance.findByIdAndDelete(id);

    if (!attendance) {
      return res.status(404).json({
        success: false,
        error: 'Not Found',
        message: 'Attendance record not found'
      });
    }

    logger.info('Attendance deleted', { attendanceId: id, adminId: req.userId });

    res.json({
      success: true,
      message: 'Attendance record deleted successfully'
    });
  } catch (error) {
    logger.error('Delete attendance error', { error: error.message });
    
    res.status(500).json({
      success: false,
      error: 'Delete Failed',
      message: 'An error occurred while deleting attendance record'
    });
  }
};
