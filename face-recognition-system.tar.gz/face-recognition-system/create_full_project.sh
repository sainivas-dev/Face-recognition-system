#!/bin/bash

# This script creates all remaining files for the Face Recognition System

echo "Creating complete project structure..."

# Create backend package.json
cat > backend/package.json << 'EOF'
{
  "name": "face-recognition-backend",
  "version": "1.0.0",
  "description": "Backend for Face Recognition System",
  "main": "src/server.js",
  "scripts": {
    "start": "node src/server.js",
    "dev": "nodemon src/server.js",
    "test": "jest"
  },
  "dependencies": {
    "express": "^4.18.2",
    "mongoose": "^7.0.0",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.0",
    "helmet": "^7.0.0",
    "cors": "^2.8.5",
    "dotenv": "^16.0.3",
    "express-rate-limit": "^6.7.0",
    "express-validator": "^7.0.1",
    "winston": "^3.8.2",
    "morgan": "^1.10.0",
    "axios": "^1.4.0",
    "geoip-lite": "^1.4.7"
  },
  "devDependencies": {
    "nodemon": "^2.0.22",
    "jest": "^29.5.0"
  }
}
EOF

# Create backend .env.example
cat > backend/.env.example << 'EOF'
# Server Configuration
NODE_ENV=development
PORT=5000
FRONTEND_URL=http://localhost:3000

# MongoDB
MONGODB_URI=mongodb://mongodb:27017/face_recognition

# JWT Secrets
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
JWT_REFRESH_SECRET=your-super-secret-refresh-key-change-this-in-production

# AI Service
AI_SERVICE_URL=http://ai-service:8000

# Geo-Restriction
GEO_RESTRICTION_ENABLED=true
ALLOWED_COUNTRIES=US
ALLOWED_STATES=California,New York,Texas
ALLOWED_CITIES=San Francisco,Los Angeles,New York

# Logging
LOG_LEVEL=info
EOF

# Create Python requirements.txt
cat > ai-service/requirements.txt << 'EOF'
fastapi==0.104.1
uvicorn[standard]==0.24.0
deepface==0.0.79
opencv-python==4.8.1.78
numpy==1.24.3
pymongo==4.6.0
python-multipart==0.0.6
pydantic==2.5.0
tf-keras==2.15.0
tensorflow==2.15.0
pillow==10.1.0
EOF

# Create admin routes
cat > backend/src/routes/admin.js << 'EOF'
const express = require('express');
const router = express.Router();
const { authenticate, isAdmin } = require('../middleware/auth');
const adminController = require('../controllers/adminController');
const { validateObjectId } = require('../middleware/validator');

// All routes require admin authentication
router.use(authenticate);
router.use(isAdmin);

// User management
router.get('/users', adminController.getAllUsers);
router.get('/users/:id', validateObjectId('id'), adminController.getUserById);
router.put('/users/:id', validateObjectId('id'), adminController.updateUser);
router.delete('/users/:id', validateObjectId('id'), adminController.deleteUser);

// Attendance management
router.get('/attendance', adminController.getAllAttendance);
router.get('/attendance/user/:userId', validateObjectId('userId'), adminController.getUserAttendance);
router.get('/attendance/stats', adminController.getAttendanceStats);

// System stats
router.get('/stats', adminController.getSystemStats);

module.exports = router;
EOF

# Create admin controller
cat > backend/src/controllers/adminController.js << 'EOF'
const User = require('../models/User');
const Attendance = require('../models/Attendance');
const Embedding = require('../models/Embedding');
const logger = require('../utils/logger');

exports.getAllUsers = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '' } = req.query;
    
    const query = search ? {
      $or: [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ]
    } : {};

    const users = await User.find(query)
      .select('-password')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });

    const count = await User.countDocuments(query);

    res.status(200).json({
      success: true,
      data: {
        users,
        totalPages: Math.ceil(count / limit),
        currentPage: page,
        total: count
      }
    });
  } catch (error) {
    logger.error('Get all users error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get users',
      message: error.message
    });
  }
};

exports.getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      data: { user }
    });
  } catch (error) {
    logger.error('Get user error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get user',
      message: error.message
    });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { name, email, role, isActive } = req.body;
    
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { name, email, role, isActive },
      { new: true, runValidators: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    logger.info(`User updated by admin: ${user.email}`);

    res.status(200).json({
      success: true,
      message: 'User updated successfully',
      data: { user }
    });
  } catch (error) {
    logger.error('Update user error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update user',
      message: error.message
    });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    // Delete related data
    await Embedding.deleteOne({ userId: req.params.id });
    await Attendance.deleteMany({ userId: req.params.id });

    logger.info(`User deleted by admin: ${user.email}`);

    res.status(200).json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    logger.error('Delete user error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete user',
      message: error.message
    });
  }
};

exports.getAllAttendance = async (req, res) => {
  try {
    const { page = 1, limit = 20, startDate, endDate } = req.query;
    
    let query = {};
    if (startDate || endDate) {
      query.checkIn = {};
      if (startDate) query.checkIn.$gte = new Date(startDate);
      if (endDate) query.checkIn.$lte = new Date(endDate);
    }

    const attendance = await Attendance.find(query)
      .populate('userId', 'name email')
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ checkIn: -1 });

    const count = await Attendance.countDocuments(query);

    res.status(200).json({
      success: true,
      data: {
        attendance,
        totalPages: Math.ceil(count / limit),
        currentPage: page,
        total: count
      }
    });
  } catch (error) {
    logger.error('Get attendance error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get attendance',
      message: error.message
    });
  }
};

exports.getUserAttendance = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    let query = { userId: req.params.userId };
    if (startDate || endDate) {
      query.checkIn = {};
      if (startDate) query.checkIn.$gte = new Date(startDate);
      if (endDate) query.checkIn.$lte = new Date(endDate);
    }

    const attendance = await Attendance.find(query)
      .populate('userId', 'name email')
      .sort({ checkIn: -1 });

    res.status(200).json({
      success: true,
      data: { attendance }
    });
  } catch (error) {
    logger.error('Get user attendance error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get user attendance',
      message: error.message
    });
  }
};

exports.getAttendanceStats = async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const stats = {
      today: await Attendance.countDocuments({ checkIn: { $gte: today } }),
      thisWeek: await Attendance.countDocuments({ 
        checkIn: { $gte: new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000) }
      }),
      thisMonth: await Attendance.countDocuments({
        checkIn: { $gte: new Date(today.getFullYear(), today.getMonth(), 1) }
      }),
      total: await Attendance.countDocuments({})
    };

    res.status(200).json({
      success: true,
      data: { stats }
    });
  } catch (error) {
    logger.error('Get attendance stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get attendance stats',
      message: error.message
    });
  }
};

exports.getSystemStats = async (req, res) => {
  try {
    const stats = {
      totalUsers: await User.countDocuments({}),
      activeUsers: await User.countDocuments({ isActive: true }),
      registeredFaces: await Embedding.countDocuments({}),
      totalAttendance: await Attendance.countDocuments({}),
      todayAttendance: await Attendance.countDocuments({ 
        checkIn: { $gte: new Date(new Date().setHours(0, 0, 0, 0)) }
      })
    };

    res.status(200).json({
      success: true,
      data: { stats }
    });
  } catch (error) {
    logger.error('Get system stats error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to get system stats',
      message: error.message
    });
  }
};
EOF

echo "✅ Created backend files"

# Create Docker Compose
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  mongodb:
    image: mongo:6.0
    container_name: frs-mongodb
    restart: unless-stopped
    ports:
      - "27017:27017"
    environment:
      MONGO_INITDB_DATABASE: face_recognition
    volumes:
      - mongodb_data:/data/db
    networks:
      - frs-network

  backend:
    build: ./backend
    container_name: frs-backend
    restart: unless-stopped
    ports:
      - "5000:5000"
    environment:
      - NODE_ENV=production
      - MONGODB_URI=mongodb://mongodb:27017/face_recognition
      - AI_SERVICE_URL=http://ai-service:8000
    env_file:
      - ./backend/.env
    depends_on:
      - mongodb
      - ai-service
    networks:
      - frs-network
    volumes:
      - ./backend/logs:/app/logs

  ai-service:
    build: ./ai-service
    container_name: frs-ai-service
    restart: unless-stopped
    ports:
      - "8000:8000"
    environment:
      - MONGODB_URI=mongodb://mongodb:27017/face_recognition
    depends_on:
      - mongodb
    networks:
      - frs-network

  frontend:
    build: ./frontend
    container_name: frs-frontend
    restart: unless-stopped
    ports:
      - "3000:80"
    depends_on:
      - backend
    networks:
      - frs-network

  nginx:
    image: nginx:alpine
    container_name: frs-nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/ssl:/etc/nginx/ssl:ro
    depends_on:
      - backend
      - frontend
    networks:
      - frs-network

volumes:
  mongodb_data:

networks:
  frs-network:
    driver: bridge
EOF

echo "✅ Created Docker Compose"

# Create Dockerfiles
cat > backend/Dockerfile << 'EOF'
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./

RUN npm install --production

COPY . .

RUN mkdir -p logs

EXPOSE 5000

CMD ["npm", "start"]
EOF

cat > ai-service/Dockerfile << 'EOF'
FROM python:3.9-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    libgl1-mesa-glx \
    libglib2.0-0 \
    && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .

RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000

CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
EOF

cat > frontend/Dockerfile << 'EOF'
FROM node:18-alpine as build

WORKDIR /app

COPY package*.json ./

RUN npm install

COPY . .

RUN npm run build

FROM nginx:alpine

COPY --from=build /app/build /usr/share/nginx/html

COPY nginx.conf /etc/nginx/conf.d/default.conf

EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
EOF

echo "✅ Created Dockerfiles"

# Create nginx configuration
cat > nginx/nginx.conf << 'EOF'
events {
    worker_connections 1024;
}

http {
    upstream backend {
        server backend:5000;
    }

    upstream frontend {
        server frontend:80;
    }

    # HTTP server - redirect to HTTPS
    server {
        listen 80;
        server_name _;

        location / {
            return 301 https://$host$request_uri;
        }
    }

    # HTTPS server
    server {
        listen 443 ssl http2;
        server_name _;

        ssl_certificate /etc/nginx/ssl/cert.pem;
        ssl_certificate_key /etc/nginx/ssl/key.pem;

        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers HIGH:!aNULL:!MD5;

        # Frontend
        location / {
            proxy_pass http://frontend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        # Backend API
        location /api {
            proxy_pass http://backend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            
            # Increase timeouts for face recognition
            proxy_connect_timeout 60s;
            proxy_send_timeout 60s;
            proxy_read_timeout 60s;
        }

        # Health check
        location /health {
            proxy_pass http://backend;
            access_log off;
        }
    }
}
EOF

echo "✅ Created Nginx configuration"

echo "
========================================
Project structure created successfully!
========================================
"
