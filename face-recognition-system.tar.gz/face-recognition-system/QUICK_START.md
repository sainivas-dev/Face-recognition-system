# Quick Start Guide

## 🚀 Get Started in 5 Minutes

### Prerequisites
- Docker and Docker Compose installed
- 8GB RAM minimum
- 50GB free disk space

### Step 1: Clone and Configure

```bash
cd face-recognition-system

# Configure backend
cp backend/.env.example backend/.env
# Edit backend/.env - Set strong JWT_SECRET values

# Configure frontend
cp frontend/.env.example frontend/.env
```

### Step 2: Generate SSL Certificates (Development)

```bash
mkdir -p nginx/ssl
cd nginx/ssl
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout key.pem -out cert.pem \
  -subj "/C=US/ST=CA/L=SF/O=Dev/CN=localhost"
cd ../..
```

### Step 3: Start All Services

```bash
docker-compose up -d
```

Wait 2-3 minutes for all services to start.

### Step 4: Access the Application

- Frontend: https://localhost (accept self-signed cert warning)
- Backend API: https://localhost/api/health
- Backend Direct: http://localhost:5000/health

### Step 5: Register Your First User

1. Go to https://localhost
2. Click "Sign Up"
3. Fill in your details
4. After registration, go to Dashboard
5. Click "Register Face" to enroll your face
6. Allow camera access and capture your face

### Step 6: Test Face Login

1. Logout
2. Click "Face Recognition" tab
3. Allow camera access
4. Your face will be recognized and logged in automatically!

## 📊 System Status

Check if all services are running:
```bash
docker-compose ps
```

Should show:
- frs-mongodb (healthy)
- frs-backend (healthy)
- frs-ai-service (healthy)
- frs-frontend (healthy)
- frs-nginx (healthy)

## 🔧 Troubleshooting

**Issue: Services won't start**
```bash
docker-compose down -v
docker-compose up -d --build
```

**Issue: Face detection fails**
```bash
# Check AI service logs
docker-compose logs ai-service
```

**Issue: Cannot access https://localhost**
- Accept the self-signed certificate warning in your browser
- Or use http://localhost:3000 directly (frontend only)

## 🎯 Default Configuration

- **Geo-Restriction**: DISABLED in development (set in .env)
- **Face Model**: Facenet (high accuracy)
- **Verification Threshold**: 0.40 (configurable in ai-service/app/main.py)

## 📚 Next Steps

- Read [README.md](README.md) for complete documentation
- Check [DEPLOYMENT.md](DEPLOYMENT.md) for production deployment
- Review [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) for architecture

## 🆘 Need Help?

Check logs:
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f ai-service
```

Stop system:
```bash
docker-compose down
```

Clean restart:
```bash
docker-compose down -v
docker-compose up -d --build
```

---

**You're all set! Start recognizing faces! 🎉**
