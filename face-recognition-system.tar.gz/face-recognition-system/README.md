# Face Recognition System (FRS)

A production-ready face recognition system with web application featuring user authentication, attendance marking, and geo-restriction capabilities.

## 🌟 Features

- **Face Recognition Authentication**: Login using facial biometrics
- **User Registration**: Traditional email/password registration with face enrollment
- **Attendance System**: Mark attendance with face verification and confidence scoring
- **Geo-Restriction**: IP-based location validation for security
- **Role-Based Access Control**: Admin and user roles with different permissions
- **Real-time Face Detection**: Using DeepFace and Facenet models
- **Secure**: JWT authentication, HTTPS, rate limiting, Helmet.js security headers
- **Scalable**: Microservice architecture with Docker containerization

## 🏗️ Architecture

```
┌─────────────┐      ┌──────────────┐      ┌────────────────┐
│   Frontend  │─────▶│    Nginx     │─────▶│    Backend     │
│   (React)   │      │  (Reverse    │      │  (Node.js +    │
│             │      │   Proxy)     │      │   Express)     │
└─────────────┘      └──────────────┘      └────────────────┘
                              │                      │
                              │                      ▼
                              │            ┌────────────────┐
                              │            │   AI Service   │
                              │            │  (Python +     │
                              │            │   FastAPI)     │
                              │            └────────────────┘
                              │                      │
                              ▼                      ▼
                     ┌────────────────────────────────┐
                     │         MongoDB                │
                     │  (Users, Embeddings,           │
                     │   Attendance)                  │
                     └────────────────────────────────┘
```

## 📋 Prerequisites

- Docker & Docker Compose
- Node.js 18+ (for local development)
- Python 3.9+ (for local development)
- MongoDB 6.0+
- 4GB+ RAM (for AI models)

## 🚀 Quick Start

### 1. Clone the Repository

```bash
git clone <repository-url>
cd face-recognition-system
```

### 2. Configure Environment Variables

#### Backend Configuration
```bash
cp backend/.env.example backend/.env
# Edit backend/.env with your settings
```

Key environment variables:
```env
NODE_ENV=production
PORT=5000
MONGODB_URI=mongodb://mongodb:27017/face_recognition
JWT_SECRET=your-super-secret-jwt-key
AI_SERVICE_URL=http://ai-service:8000

# Geo-Restriction Settings
GEO_RESTRICTION_ENABLED=true
ALLOWED_COUNTRIES=US
ALLOWED_STATES=California,New York
ALLOWED_CITIES=San Francisco,Los Angeles
```

#### Frontend Configuration
```bash
cp frontend/.env.example frontend/.env
```

```env
REACT_APP_API_URL=http://localhost:5000/api
```

### 3. Generate SSL Certificates

For development:
```bash
mkdir -p nginx/ssl
cd nginx/ssl
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout key.pem -out cert.pem \
  -subj "/C=US/ST=State/L=City/O=Organization/CN=localhost"
cd ../..
```

For production, use Let's Encrypt or your certificate authority.

### 4. Start the System

```bash
docker-compose up -d
```

This will start:
- MongoDB on port 27017
- Backend API on port 5000
- AI Service on port 8000
- Frontend on port 3000
- Nginx reverse proxy on ports 80 (HTTP) and 443 (HTTPS)

### 5. Verify Installation

Check all services are running:
```bash
docker-compose ps
```

Access the application:
- Frontend: https://localhost
- Backend API: https://localhost/api/health
- AI Service: https://localhost/api (proxied through Nginx)

### 6. Create Admin User

```bash
# Access MongoDB
docker exec -it frs-mongodb mongosh face_recognition

# Create admin user
db.users.insertOne({
  email: "admin@example.com",
  name: "Admin User",
  password: "$2a$10$hash...", // Use bcrypt to hash password
  role: "admin",
  faceRegistered: false,
  isActive: true,
  createdAt: new Date(),
  updatedAt: new Date()
});
```

## 🔧 Development Setup

### Backend Development

```bash
cd backend
npm install
npm run dev
```

### Frontend Development

```bash
cd frontend
npm install
npm start
```

### AI Service Development

```bash
cd ai-service
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## 🌍 Geo-Restriction Configuration

The system supports IP-based geo-restriction to limit access by location:

### Configuration Options

1. **Disable geo-restriction** (for testing):
```env
GEO_RESTRICTION_ENABLED=false
```

2. **Restrict by country**:
```env
ALLOWED_COUNTRIES=US,CA,GB
```

3. **Restrict by state/region**:
```env
ALLOWED_STATES=California,Texas,New York
```

4. **Restrict by city**:
```env
ALLOWED_CITIES=San Francisco,Los Angeles,New York City
```

### How It Works

- Uses `geoip-lite` library for IP geolocation
- Validates incoming requests against configured locations
- Returns 403 Forbidden for blocked locations
- Bypasses localhost in development mode

### Testing Geo-Restriction

```bash
# Test from allowed location
curl -H "X-Forwarded-For: 8.8.8.8" https://localhost/api/auth/login

# Test from blocked location
curl -H "X-Forwarded-For: 1.1.1.1" https://localhost/api/auth/login
```

## 📊 API Documentation

### Authentication Endpoints

#### Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "SecurePass123"
}
```

#### Login with Password
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "SecurePass123"
}
```

#### Register Face
```http
POST /api/auth/register-face
Authorization: Bearer <token>
Content-Type: application/json

{
  "image": "data:image/jpeg;base64,/9j/4AAQSkZJRg..."
}
```

#### Login with Face
```http
POST /api/auth/face-login
Content-Type: application/json

{
  "image": "data:image/jpeg;base64,/9j/4AAQSkZJRg..."
}
```

### Attendance Endpoints

#### Mark Attendance
```http
POST /api/attendance/mark
Authorization: Bearer <token>
Content-Type: application/json

{
  "image": "data:image/jpeg;base64,/9j/4AAQSkZJRg...",
  "type": "checkIn"  // or "checkOut"
}
```

#### Get My Attendance
```http
GET /api/attendance/my-attendance?startDate=2024-01-01&endDate=2024-12-31
Authorization: Bearer <token>
```

#### Get Today's Status
```http
GET /api/attendance/today-status
Authorization: Bearer <token>
```

### Admin Endpoints

#### Get All Users
```http
GET /api/admin/users?page=1&limit=10&search=john
Authorization: Bearer <admin-token>
```

#### Get System Stats
```http
GET /api/admin/stats
Authorization: Bearer <admin-token>
```

## 🔒 Security Features

1. **JWT Authentication**: Secure token-based authentication
2. **Password Hashing**: bcrypt with salt rounds
3. **Rate Limiting**: Prevents brute-force attacks
4. **Input Validation**: express-validator for all inputs
5. **Helmet.js**: Sets security HTTP headers
6. **CORS**: Configured for specific origins
7. **Geo-Restriction**: IP-based access control
8. **HTTPS**: TLS/SSL encryption
9. **MongoDB**: Parameterized queries prevent injection

## 🎯 Face Recognition Configuration

### Model Selection

Edit `ai-service/app/main.py`:

```python
MODEL_NAME = "Facenet"  # Options: VGG-Face, Facenet, OpenFace, DeepFace, DeepID, Dlib, ArcFace
DETECTOR_BACKEND = "opencv"  # Options: opencv, ssd, dlib, mtcnn, retinaface
DISTANCE_METRIC = "cosine"  # Options: cosine, euclidean, euclidean_l2
VERIFICATION_THRESHOLD = 0.40  # Lower = stricter verification
```

### Model Comparison

| Model | Accuracy | Speed | Size |
|-------|----------|-------|------|
| Facenet | High | Fast | Medium |
| VGG-Face | High | Medium | Large |
| ArcFace | Very High | Medium | Large |
| OpenFace | Medium | Very Fast | Small |

## 📦 Deployment

### AWS Deployment

1. **EC2 Setup**:
```bash
# Launch Ubuntu 22.04 instance (t3.large recommended)
# Open ports: 22, 80, 443, 27017

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo apt install docker-compose

# Clone and deploy
git clone <repo>
cd face-recognition-system
docker-compose up -d
```

2. **Configure Security Groups**:
- Allow HTTPS (443) from specific IP ranges
- Restrict MongoDB (27017) to internal network
- Enable SSH (22) from your IP only

3. **Set up RDS for MongoDB** (recommended for production):
- Use MongoDB Atlas or AWS DocumentDB
- Update MONGODB_URI in environment variables

### GCP Deployment

1. **Compute Engine Setup**:
```bash
# Create VM instance (n1-standard-2 minimum)
gcloud compute instances create frs-instance \
  --machine-type=n1-standard-2 \
  --image-family=ubuntu-2204-lts \
  --image-project=ubuntu-os-cloud

# SSH into instance
gcloud compute ssh frs-instance

# Install Docker and deploy (same as AWS)
```

2. **Cloud SQL for MongoDB**:
```bash
# Create MongoDB instance
gcloud sql instances create frs-mongodb \
  --database-version=MONGODB \
  --tier=db-custom-2-7680
```

### Kubernetes Deployment

See `k8s/` directory for Kubernetes manifests (to be added).

## 🐛 Troubleshooting

### Common Issues

1. **Face Detection Fails**:
   - Ensure good lighting
   - Face should be front-facing
   - Check webcam permissions
   - Verify AI service is running: `docker logs frs-ai-service`

2. **Geo-Restriction Blocking Localhost**:
   - Set `GEO_RESTRICTION_ENABLED=false` in development
   - Or add your IP to allowed list

3. **MongoDB Connection Failed**:
   - Check MongoDB is running: `docker ps | grep mongodb`
   - Verify connection string in `.env`
   - Check network connectivity

4. **Port Already in Use**:
   ```bash
   # Find process using port
   lsof -i :5000
   # Kill process
   kill -9 <PID>
   ```

### Logs

```bash
# View all logs
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f ai-service

# Backend application logs
tail -f backend/logs/combined.log
```

## 📈 Performance Optimization

1. **Use Production MongoDB**: MongoDB Atlas or AWS DocumentDB
2. **Enable Caching**: Redis for session management
3. **CDN**: CloudFlare or AWS CloudFront for static assets
4. **Load Balancing**: Multiple backend/AI service instances
5. **Image Optimization**: Compress webcam images before sending
6. **Database Indexing**: Already configured in models

## 🧪 Testing

```bash
# Backend tests
cd backend
npm test

# API tests with curl
./test-api.sh

# Load testing
ab -n 1000 -c 10 https://localhost/api/health
```

## 📝 License

MIT License - See LICENSE file for details

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📞 Support

For issues and questions:
- GitHub Issues: <repository-url>/issues
- Email: support@example.com

## 🔄 Updates & Maintenance

### Updating Dependencies

```bash
# Backend
cd backend && npm update

# Frontend
cd frontend && npm update

# AI Service
cd ai-service && pip install -U -r requirements.txt
```

### Database Backups

```bash
# Backup MongoDB
docker exec frs-mongodb mongodump --out /backup

# Restore MongoDB
docker exec frs-mongodb mongorestore /backup
```

---

**Built with ❤️ using React, Node.js, Python, and DeepFace**
