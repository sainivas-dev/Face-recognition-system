# Face Recognition System - Quick Start Guide

## ⚡ Get Started in 5 Minutes

### Prerequisites
- Docker and Docker Compose installed
- 4GB+ RAM available
- Port 3000, 5000, 8000, 27017 available

### Step 1: Download and Configure

```bash
# Clone the repository
git clone <your-repo-url>
cd face-recognition-system

# Create environment files
cp backend/.env.example backend/.env
cp ai-service/.env.example ai-service/.env
cp frontend/.env.example frontend/.env
```

### Step 2: Start the System

```bash
# Start all services
docker-compose -f deployment/docker-compose.yml up -d

# Wait for services to be ready (2-3 minutes)
# Watch the logs
docker-compose -f deployment/docker-compose.yml logs -f
```

### Step 3: Access the Application

Open your browser and navigate to:
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000/health
- **AI Service**: http://localhost:8000/docs

### Step 4: Create Your First User

1. Go to http://localhost:3000/register
2. Fill in user details:
   - Username: testuser
   - Email: test@example.com
   - Password: Test123!@#
   - Full Name: Test User
3. Click "Capture Face" and allow webcam access
4. Take a clear photo of your face
5. Click "Register"

### Step 5: Login with Face

1. Go to http://localhost:3000/login
2. Enter your email
3. Click "Login with Face"
4. Allow webcam access
5. Look at the camera
6. You're logged in!

### Step 6: Mark Attendance

1. From the dashboard, click "Mark Attendance"
2. Allow webcam access
3. Capture your face
4. Attendance marked!

## 🎯 Testing the API

### Register User (with curl)
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "apiuser",
    "email": "api@example.com",
    "password": "ApiTest123!",
    "fullName": "API Test User",
    "faceImage": "data:image/jpeg;base64,/9j/4AAQ..."
  }'
```

### Check Health
```bash
curl http://localhost:5000/health
curl http://localhost:8000/health
```

## 🔧 Configuration

### Geo-Restriction

Edit `backend/.env`:
```env
ENABLE_GEO_RESTRICTION=true
ALLOWED_COUNTRIES=US,CA,GB,IN
ALLOWED_STATES=CA,NY,TX,Maharashtra
ALLOWED_CITIES=San Francisco,Mumbai
IP_WHITELIST=127.0.0.1,::1,192.168.1.0/24
```

### Face Recognition Settings

Edit `ai-service/.env`:
```env
FACE_MODEL=Facenet512
DETECTOR_BACKEND=opencv
FACE_MATCH_THRESHOLD=0.4
```

## 📊 Viewing Data

### MongoDB
```bash
# Access MongoDB
docker exec -it frs-mongodb mongosh

# Use database
use face-recognition-system

# View users
db.users.find().pretty()

# View attendance
db.attendances.find().pretty()
```

## 🛑 Stopping the System

```bash
# Stop all services
docker-compose -f deployment/docker-compose.yml down

# Stop and remove volumes (WARNING: Deletes all data)
docker-compose -f deployment/docker-compose.yml down -v
```

## 🐛 Troubleshooting

### Services won't start
```bash
# Check logs
docker-compose logs backend
docker-compose logs ai-service

# Restart a specific service
docker-compose restart backend
```

### Can't access MongoDB
```bash
# Check if MongoDB is running
docker ps | grep mongodb

# View MongoDB logs
docker logs frs-mongodb
```

### Face detection not working
- Ensure good lighting
- Face should be clearly visible
- Try different detector backend in ai-service/.env

### Port already in use
```bash
# Change ports in docker-compose.yml
# Frontend: Change 3000:80 to 3001:80
# Backend: Change 5000:5000 to 5001:5000
# AI Service: Change 8000:8000 to 8001:8000
```

## 📚 Next Steps

1. Read [DEPLOYMENT.md](DEPLOYMENT.md) for production deployment
2. Read [ARCHITECTURE.md](ARCHITECTURE.md) for system details
3. Explore the API documentation at http://localhost:8000/docs
4. Check out the admin panel features

## 🆘 Need Help?

- Check logs: `docker-compose logs -f`
- View running containers: `docker ps`
- Check disk space: `df -h`
- Check memory: `free -h`

## 🎉 Success!

You now have a fully functional face recognition system running locally!

Try these features:
- ✅ User registration with face capture
- ✅ Face-based login
- ✅ Attendance marking
- ✅ User dashboard
- ✅ Admin panel (create admin user first)
- ✅ Geo-restriction (configure in .env)
