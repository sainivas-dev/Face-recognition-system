#!/bin/bash

echo "================================================"
echo "  Building Frontend for Production"
echo "================================================"

# Check environment
if [ ! -f ".env" ]; then
    echo "⚠️  No .env file found"
    echo "Creating from .env.example..."
    cp .env.example .env
    echo "Please update .env with production API URL"
    exit 1
fi

# Install dependencies
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

# Build
echo "Building production bundle..."
npm run build

if [ $? -eq 0 ]; then
    echo ""
    echo "================================================"
    echo "  ✅ Build Complete!"
    echo "================================================"
    echo ""
    echo "Output: build/"
    echo "Size:"
    du -sh build/
    echo ""
    echo "Deploy the build/ directory to your web server"
    echo "Or use: npx serve -s build"
    echo ""
else
    echo "❌ Build failed!"
    exit 1
fi
