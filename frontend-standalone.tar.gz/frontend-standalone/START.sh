#!/bin/bash

echo "================================================"
echo "  Face Recognition Frontend - Startup Script"
echo "================================================"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed!${NC}"
    echo "Install from: https://nodejs.org/"
    exit 1
fi

echo -e "${GREEN}✅ Node.js $(node --version)${NC}"

# Step 1: Install Dependencies
echo -e "\n${BLUE}Step 1: Installing dependencies...${NC}"

if [ ! -d "node_modules" ]; then
    echo "Installing packages..."
    npm install
else
    echo "Dependencies already installed"
fi

# Step 2: Configure Environment
echo -e "\n${BLUE}Step 2: Configuring environment...${NC}"

if [ ! -f ".env" ]; then
    cp .env.example .env
    echo -e "${GREEN}✅ .env file created${NC}"
    echo ""
    echo "Backend API URL: http://localhost:5000/api"
    echo "Update .env if your backend is on a different URL"
    echo ""
fi

# Step 3: Check Backend
echo -e "\n${BLUE}Step 3: Checking backend connection...${NC}"

BACKEND_URL=$(grep REACT_APP_API_URL .env | cut -d '=' -f2)
BACKEND_HOST=$(echo $BACKEND_URL | sed 's|/api||')

if curl -s "${BACKEND_HOST}/health" > /dev/null; then
    echo -e "${GREEN}✅ Backend is reachable at ${BACKEND_HOST}${NC}"
else
    echo -e "${YELLOW}⚠️  Backend is not responding at ${BACKEND_HOST}${NC}"
    echo "Make sure the backend is running before using the frontend"
    echo "Start backend with: cd ../backend-standalone && ./START.sh"
    echo ""
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Step 4: Start Development Server
echo -e "\n${BLUE}Step 4: Starting development server...${NC}"

echo ""
echo "================================================"
echo "  Starting React Development Server"
echo "================================================"
echo ""
echo "The app will open at: http://localhost:3000"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

npm start
