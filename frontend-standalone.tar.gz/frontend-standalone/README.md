# Face Recognition System - Frontend

Standalone React frontend with beautiful glassmorphism UI for face recognition authentication and attendance management.

## 🎨 Features

- ✅ **Modern UI Design** - Glassmorphism effects with Tailwind CSS
- ✅ **Dual Authentication** - Password and face recognition login
- ✅ **Webcam Integration** - Real-time face capture
- ✅ **Responsive Design** - Works on desktop, tablet, and mobile
- ✅ **Dashboard** - User statistics and quick actions
- ✅ **Attendance System** - Check-in/out with face verification
- ✅ **Admin Panel** - User and attendance management
- ✅ **Real-time Updates** - Dynamic UI updates

## 🏗️ Architecture

```
frontend-standalone/
├── public/
│   └── index.html         # HTML template
├── src/
│   ├── components/        # React components
│   │   ├── Register.jsx   # User registration
│   │   ├── Login.jsx      # Dual-mode login
│   │   ├── Dashboard.jsx  # Main dashboard
│   │   ├── Attendance.jsx # Attendance marking
│   │   └── AdminPanel.jsx # Admin interface
│   ├── services/
│   │   └── api.js         # API client (Axios)
│   ├── utils/
│   │   └── auth.js        # Auth helpers
│   ├── App.jsx            # Main app
│   ├── index.js           # Entry point
│   └── index.css          # Tailwind styles
├── package.json
├── tailwind.config.js
└── .env.example
```

## 📋 Prerequisites

- **Node.js** 18+
- **npm** or **yarn**
- **Backend API** running (see backend-standalone)

## 🚀 Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env`:

```env
REACT_APP_API_URL=http://localhost:5000/api
```

### 3. Start Development Server

```bash
npm start
```

The app will open at `http://localhost:3000`

### 4. Build for Production

```bash
npm run build
```

Build output will be in the `build/` directory.

## 🎯 Pages & Routes

### Public Routes

**Login** - `/login`
- Password login
- Face recognition login
- Toggle between modes

**Register** - `/register`
- User registration form
- Email, name, password
- Automatic login after registration

### Protected Routes

**Dashboard** - `/dashboard`
- Welcome message
- Attendance statistics (month, week, total)
- Face registration modal
- Quick action buttons

**Attendance** - `/attendance`
- Mark check-in/check-out with face
- Today's status
- Recent attendance history
- Confidence scores

**Admin Panel** - `/admin` (Admin only)
- System statistics
- User management table
- Attendance reports
- User status controls

## 🎨 UI Components

### Register Component
```jsx
<Register />
```
- Glassmorphism card design
- Form validation
- Password strength indicator
- Redirect to dashboard on success

### Login Component
```jsx
<Login />
```
- Dual-mode tabs (Password/Face)
- Webcam integration
- Real-time face detection animation
- Error handling

### Dashboard Component
```jsx
<Dashboard user={user} />
```
- User profile section
- Stats cards (animated)
- Face registration modal
- Quick action cards
- Navigation bar

### Attendance Component
```jsx
<Attendance user={user} />
```
- Check-in/Check-out buttons
- Live webcam feed
- Attendance history list
- Status indicators
- Confidence badges

### AdminPanel Component
```jsx
<AdminPanel />
```
- System statistics grid
- User data table
- Sortable columns
- Role badges
- Status indicators

## 🔌 API Integration

### API Service (`services/api.js`)

```javascript
import { authAPI, attendanceAPI, adminAPI } from './services/api';

// Authentication
await authAPI.register({ name, email, password });
await authAPI.login({ email, password });
await authAPI.faceLogin({ image });
await authAPI.registerFace({ image });

// Attendance
await attendanceAPI.markAttendance({ image, type });
await attendanceAPI.getMyAttendance({ startDate, endDate });
await attendanceAPI.getTodayStatus();

// Admin
await adminAPI.getAllUsers({ page, limit });
await adminAPI.getSystemStats();
```

### Auth Utilities (`utils/auth.js`)

```javascript
import { setToken, getToken, isAuthenticated, logout } from './utils/auth';

// Store token
setToken(token);

// Check authentication
if (isAuthenticated()) {
  // User is logged in
}

// Logout
logout(); // Clears tokens and redirects
```

## 🎨 Styling

### Tailwind CSS

Custom configuration in `tailwind.config.js`:

```javascript
module.exports = {
  content: ["./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      }
    },
  }
}
```

### Glassmorphism Effect

```css
.glass-effect {
  @apply bg-white/10 backdrop-blur-lg border border-white/20;
}
```

### Color Palette

- **Primary**: Purple gradients (`purple-500` to `pink-600`)
- **Secondary**: Cyan to blue (`cyan-500` to `blue-600`)
- **Success**: Green (`green-500`)
- **Error**: Red (`red-500`)
- **Background**: Dark gradients (`slate-900`, `purple-900`)

## 📱 Responsive Design

The app is fully responsive with breakpoints:

- **Mobile**: < 640px
- **Tablet**: 640px - 1024px
- **Desktop**: > 1024px

```jsx
// Responsive grid example
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
  {/* Cards */}
</div>
```

## 🔐 Authentication Flow

### Registration Flow
1. User fills registration form
2. Submit to `/api/auth/register`
3. Receive JWT token
4. Store token in localStorage
5. Redirect to dashboard

### Password Login Flow
1. User enters credentials
2. Submit to `/api/auth/login`
3. Receive JWT token
4. Store token and user data
5. Redirect to dashboard

### Face Login Flow
1. User clicks "Face Recognition" tab
2. Webcam activates
3. User clicks "Login with Face"
4. Capture image as base64
5. Submit to `/api/auth/face-login`
6. Receive token and user data
7. Redirect to dashboard

### Face Registration Flow
1. Authenticated user opens dashboard
2. Click "Register Face" button
3. Modal opens with webcam
4. Click "Capture & Register"
5. Submit to `/api/auth/register-face`
6. Face embedding stored on backend
7. User can now use face login

## 🧪 Development

### Available Scripts

```bash
# Start development server
npm start

# Run tests
npm test

# Build for production
npm run build

# Eject webpack config (not recommended)
npm run eject
```

### Environment Variables

```env
# Backend API URL
REACT_APP_API_URL=http://localhost:5000/api

# Optional: Enable debug mode
REACT_APP_DEBUG=true
```

## 📦 Dependencies

```json
{
  "react": "^18.2.0",
  "react-dom": "^18.2.0",
  "react-router-dom": "^6.11.0",
  "react-webcam": "^7.1.1",
  "axios": "^1.4.0",
  "tailwindcss": "^3.3.0"
}
```

## 🎭 Component Props

### PrivateRoute
```jsx
<PrivateRoute adminOnly={false}>
  <Dashboard />
</PrivateRoute>
```

Props:
- `children` - Component to render
- `adminOnly` - Require admin role (default: false)

### Webcam Integration

```jsx
import Webcam from 'react-webcam';

const webcamRef = useRef(null);

<Webcam
  ref={webcamRef}
  audio={false}
  screenshotFormat="image/jpeg"
  videoConstraints={{ facingMode: 'user' }}
/>

// Capture image
const imageSrc = webcamRef.current.getScreenshot();
```

## 🔒 Security

### Token Storage

Tokens are stored in localStorage:
```javascript
localStorage.setItem('token', token);
localStorage.setItem('user', JSON.stringify(user));
```

### Protected Routes

Routes check authentication status:
```jsx
if (!isAuthenticated()) {
  return <Navigate to="/login" />;
}
```

### API Interceptors

Axios automatically adds auth headers:
```javascript
api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
```

## 🎨 Custom Hooks (Optional)

Create custom hooks for common functionality:

```javascript
// useAuth.js
export const useAuth = () => {
  const [user, setUser] = useState(getUser());
  
  const login = (userData, token) => {
    setToken(token);
    setUser(userData);
  };
  
  const logout = () => {
    removeToken();
    setUser(null);
  };
  
  return { user, login, logout, isAuthenticated: !!user };
};
```

## 🐛 Troubleshooting

### CORS Errors

If you see CORS errors:
1. Check backend is running
2. Verify `REACT_APP_API_URL` is correct
3. Ensure backend CORS is configured for `http://localhost:3000`

### Camera Not Working

1. Check browser permissions
2. Ensure HTTPS (required for camera in production)
3. Try different browser
4. Check webcam is not used by another app

### Build Fails

```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Hot Reload Not Working

```bash
# Restart dev server
npm start
```

## 🚀 Deployment

### Static Hosting (Netlify, Vercel)

1. Build the app:
```bash
npm run build
```

2. Deploy `build/` folder

3. Configure environment variables on hosting platform:
```
REACT_APP_API_URL=https://your-api-domain.com/api
```

### Nginx

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /var/www/app/build;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

### Docker

```dockerfile
FROM node:18-alpine as build

WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/build /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

## 📊 Performance Optimization

### Code Splitting

```javascript
// Lazy load components
const AdminPanel = lazy(() => import('./components/AdminPanel'));

<Suspense fallback={<Loading />}>
  <AdminPanel />
</Suspense>
```

### Image Optimization

- Compress webcam captures before sending
- Use appropriate image formats
- Implement lazy loading for images

### Bundle Size

```bash
# Analyze bundle
npm run build
npx source-map-explorer build/static/js/*.js
```

## 🎯 Best Practices

1. ✅ Always validate user input
2. ✅ Handle loading states
3. ✅ Display error messages clearly
4. ✅ Use environment variables for API URLs
5. ✅ Implement proper error boundaries
6. ✅ Keep components small and focused
7. ✅ Use meaningful variable names
8. ✅ Add PropTypes for type checking

## 📱 PWA Support (Optional)

Convert to Progressive Web App:

1. Uncomment in `index.js`:
```javascript
serviceWorker.register();
```

2. Configure `manifest.json`
3. Add offline support
4. Enable push notifications

## 🤝 Integration Guide

### Connecting to Backend

1. Ensure backend is running on specified port
2. Update `REACT_APP_API_URL` in `.env`
3. Test API endpoints with browser network tab
4. Check CORS configuration matches

### Working with Different Backends

The frontend works with any backend that implements the expected API:

```javascript
// Expected response format
{
  "success": true,
  "message": "Operation successful",
  "data": { /* response data */ }
}
```

## 📄 License

MIT License

## 🆘 Support

For issues:
1. Check browser console for errors
2. Verify API URL is correct
3. Check network requests in DevTools
4. Ensure backend is running
5. Clear browser cache and localStorage

---

**Built with React, Tailwind CSS, and ❤️** ⚛️
